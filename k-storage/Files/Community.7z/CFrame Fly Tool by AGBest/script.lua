local plr = game:GetService("Players").LocalPlayer
local char = plr.Character or plr.CharacterAdded
local root = char.HumanoidRootPart
local humanoid = char.Humanoid
local run = game:GetService("RunService")
local cam = workspace.CurrentCamera
local tool = Instance.new("Tool")
local pos
local gyro
local cf
local dir
local direction
local event

tool.Name = "Noclip"
tool.RequiresHandle = false
tool.Parent = plr.Backpack
 
local speed = 1
 
tool.Equipped:Connect(function()
    pos = root.Position
    event = run.Heartbeat:Connect(function()
        cf = cam.CFrame.Rotation
        dir = cf:VectorToObjectSpace(humanoid.MoveDirection * speed)
        if dir.Magnitude == 0 then
            direction = Vector3.new(0,0,0)
        else
            direction = cf:VectorToWorldSpace(Vector3.new(dir.X, 0, dir.Z).Unit * dir.Magnitude)
        end
        pos = pos + direction
        root.CFrame = CFrame.new(pos, cam.CFrame.Position + (pos - cam.CFrame.Position) *2)
        root.Velocity = Vector3.new(0,0,0)
        root.RotVelocity = Vector3.new(0,0,0)
    end)
end)
 
tool.Unequipped:Connect(function()
    event:Disconnect()
end)