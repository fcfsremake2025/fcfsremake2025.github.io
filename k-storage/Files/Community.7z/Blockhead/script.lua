--[[
A distribution of https://wearedevs.net/scripts
Last updated August 2, 2021

Description: Turns your character's head into a plain block. Only you can see this.

Instruction: Inject this script into any game using a Lua executor like JJSploit. 
]]

game:GetService("Players").LocalPlayer.Head.Mesh:Destroy()