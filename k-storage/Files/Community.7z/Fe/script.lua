local Players = game:GetService("Players")

local StarterGui = game:GetService("StarterGui")

local RunService = game:GetService("RunService")

local UserInputService = game:GetService("UserInputService")

local player = Players.LocalPlayer

local playerGui = player:WaitForChild("PlayerGui")

local egorEnabled = false

local runAnimId = "rbxassetid://913376220"

local runTrack, runConnection = nil, nil

local gui, button, dragFrame

local function createGUI()

	if playerGui:FindFirstChild("EgorToggle") then

		playerGui:FindFirstChild("EgorToggle"):Destroy()

	end

	gui = Instance.new("ScreenGui")

	gui.Name = "EgorToggle"

	gui.ResetOnSpawn = false

	gui.Parent = playerGui

	dragFrame = Instance.new("Frame")

	dragFrame.Size = UDim2.new(0, 150, 0, 50)

	dragFrame.Position = UDim2.new(0, 20, 1, -70)

	dragFrame.BackgroundTransparency = 1

	dragFrame.Active = true

	dragFrame.Draggable = true

	dragFrame.Parent = gui

	button = Instance.new("TextButton")

	button.Size = UDim2.new(1, 0, 1, 0)

	button.Position = UDim2.new(0, 0, 0, 0)

	button.BackgroundColor3 = Color3.fromRGB(10, 10, 30)

	button.BorderSizePixel = 0

	button.TextColor3 = Color3.fromRGB(0, 255, 255)

	button.TextSize = 20

	button.Font = Enum.Font.GothamBold

	button.Text = "⚡ Egor: OFF"

	button.AutoButtonColor = false

	button.Parent = dragFrame

	-- Neon style: UIStroke + Glow

	local stroke = Instance.new("UIStroke")

	stroke.Color = Color3.fromRGB(0, 255, 255)

	stroke.Thickness = 2

	stroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Border

	stroke.Parent = button

	local uicorner = Instance.new("UICorner")

	uicorner.CornerRadius = UDim.new(0, 12)

	uicorner.Parent = button

	local uigrad = Instance.new("UIGradient")

	uigrad.Color = ColorSequence.new({

		ColorSequenceKeypoint.new(0, Color3.fromRGB(0, 255, 255)),

		ColorSequenceKeypoint.new(1, Color3.fromRGB(0, 180, 255))

	})

	uigrad.Rotation = 45

	uigrad.Parent = button

	button.MouseButton1Click:Connect(function()

		egorEnabled = not egorEnabled

		if egorEnabled then enableEgor() else disableEgor() end

	end)

end

local function playRunAnimation(humanoid)

	local animator = humanoid:FindFirstChildWhichIsA("Animator")

	if not animator then

		animator = Instance.new("Animator", humanoid)

	end

	local runAnim = Instance.new("Animation")

	runAnim.AnimationId = runAnimId

	runTrack = animator:LoadAnimation(runAnim)

	runTrack.Priority = Enum.AnimationPriority.Movement

	runTrack:AdjustSpeed(6)

	runTrack:Play()

	runConnection = RunService.RenderStepped:Connect(function()

		if humanoid.MoveDirection.Magnitude == 0 then

			if runTrack.IsPlaying then runTrack:Stop() end

		else

			if not runTrack.IsPlaying then

				runTrack:Play()

				runTrack:AdjustSpeed(6)

			end

		end

	end)

end

local function stopRunAnimation()

	if runTrack then runTrack:Stop() end

	if runConnection then runConnection:Disconnect() end

end

function enableEgor()

	local char = player.Character

	if not char then return end

	local humanoid = char:FindFirstChild("Humanoid")

	if not humanoid then return end

	humanoid.WalkSpeed = 3

	playRunAnimation(humanoid)

	if button then button.Text = "⚡ Egor: ON" end

end

function disableEgor()

	local char = player.Character

	if not char then return end

	local humanoid = char:FindFirstChild("Humanoid")

	if not humanoid then return end

	humanoid.WalkSpeed = 16

	stopRunAnimation()

	if button then button.Text = "⚡ Egor: OFF" end

end

local function onCharacterAdded(char)

	local humanoid = char:WaitForChild("Humanoid")

	char:WaitForChild("Animate")

	task.wait(0.5)

	if egorEnabled then

		enableEgor()

	else

		disableEgor()

	end

end

createGUI()

if player.Character then

	onCharacterAdded(player.Character)

end

player.CharacterAdded:Connect(onCharacterAdded)