getgenv().walkspeed = 40

game.Players.LocalPlayer.Character.Humanoid.Walkspeed = getgenv().walkspeed