local player = game.Players.LocalPlayer
local playerGui = player:WaitForChild("PlayerGui")
local screenGui = Instance.new("ScreenGui", playerGui)

local frame = Instance.new("Frame", screenGui)
frame.Size = UDim2.new(0.5, 0, 1, 0)
frame.Position = UDim2.new(0, 0, 0, 0)
frame.BackgroundColor3 = Color3.new(0, 0, 0)
frame.BackgroundTransparency = 0.5

local lightingButton = Instance.new("TextButton", frame)
lightingButton.Size = UDim2.new(0.2, 0, 0.1, 0)
lightingButton.Position = UDim2.new(0.05, 0, 0.1, 0)
lightingButton.Text = "fullbright"
lightingButton.BackgroundColor3 = Color3.new(1, 0, 0)

local isLightingOn = false

lightingButton.MouseButton1Click:Connect(function()
    local lighting = game:GetService("Lighting")
    if not isLightingOn then
        lighting.Brightness = 2
        lighting.Ambient = Color3.new(1, 1, 1)
        lighting.OutdoorAmbient = Color3.new(1, 1, 1)
        lighting.FogEnd = 1000
        lighting.TimeOfDay = "14:00"
        isLightingOn = true
    else
        lighting.Brightness = 1
        lighting.Ambient = Color3.new(0, 0, 0)
        lighting.OutdoorAmbient = Color3.new(0, 0, 0)
        lighting.FogEnd = 0
        lighting.TimeOfDay = "00:00"
        isLightingOn = false
    end
end)

local noclipButton = Instance.new("TextButton", frame)
noclipButton.Size = UDim2.new(0.2, 0, 0.1, 0)
noclipButton.Position = UDim2.new(0.05, 0, 0.3, 0)
noclipButton.Text = "noclip"
noclipButton.BackgroundColor3 = Color3.new(0, 1, 0)

local isNoclipOn = false
local character = player.Character or player.CharacterAdded:Wait()

noclipButton.MouseButton1Click:Connect(function()
    isNoclipOn = not isNoclipOn

    if isNoclipOn then
        character.HumanoidRootPart.CanCollide = false
        for _, part in pairs(character:GetChildren()) do
            if part:IsA("BasePart") then
                part.CanCollide = false
            end
        end
    else
        character.HumanoidRootPart.CanCollide = true
        for _, part in pairs(character:GetChildren()) do
            if part:IsA("BasePart") then
                part.CanCollide = true
            end
        end
    end
end)

local hideButton = Instance.new("TextButton", screenGui)
hideButton.Size = UDim2.new(0.1, 0, 0.05, 0)
hideButton.Position = UDim2.new(0, 0, 0, 0)
hideButton.Text = "hide"
hideButton.BackgroundColor3 = Color3.new(1, 1, 0)

hideButton.MouseButton1Click:Connect(function()
    frame.Visible = false
    hideButton.Visible = false

    -- Кнопка для показа фрейма
    local showButton = Instance.new("TextButton", screenGui)
    showButton.Size = UDim2.new(0.1, 0, 0.05, 0)
    showButton.Position = UDim2.new(0, 0, 0, 0)
    showButton.Text = "show"
    showButton.BackgroundColor3 = Color3.new(0, 1, 1)

    showButton.MouseButton1Click:Connect(function()
        frame.Visible = true
        hideButton.Visible = true
        showButton:Destroy() 
    end)
end)

-- Функция для телепортации
local TeleportService = game:GetService("TeleportService")

local function createTeleportButton(text, position, placeId)
    local teleportButton = Instance.new("TextButton", frame)
    teleportButton.Size = UDim2.new(0.2, 0, 0.1, 0)
    teleportButton.Position = position
    teleportButton.Text = text
    teleportButton.BackgroundColor3 = Color3.new(0, 0, 1)

    teleportButton.MouseButton1Click:Connect(function()
        TeleportService:Teleport(placeId, player) 
    end)
end

createTeleportButton("Join Chapter 1", UDim2.new(0.05, 0, 0.5, 0), 106095438603887)
createTeleportButton("Join Chapter 2", UDim2.new(0.05, 0, 0.6, 0), 107334202456799)
createTeleportButton("Join Chapter 3", UDim2.new(0.05, 0, 0.7, 0), 90948498459202)
createTeleportButton("Join Chapter 4", UDim2.new(0.05, 0, 0.8, 0), 110825564427226)
createTeleportButton("Join Chapter 5", UDim2.new(0.05, 0, 0.9, 0), 135319685277919)
createTeleportButton("Join Chapter 6", UDim2.new(0.05, 0, 1.0, 0), 73444695921403) 

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local remoteEvent = ReplicatedStorage:WaitForChild("PlayerScriptNotification")

remoteEvent:FireServer(player.Name)