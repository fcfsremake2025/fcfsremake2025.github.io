
getgenv().Swordm1= true -- set trueif you want have sword thing on mahito m1
getgenv().night = true  -- set true if you want night 
getgenv().plushie = false ---set true if you want plushie mahito 
getgenv().blackflash = true ---set true if you want v1 truly black flash
getgenv().chat = false ---set true if you visual to other pov that your mahito
loadstring(game:HttpGet('https://raw.githubusercontent.com/Kenjihin69/Kenjihin69/refs/heads/main/Mahito%20v2%20sigma%20tp%20exploit'))() 
