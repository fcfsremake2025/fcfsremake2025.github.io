local plr = game:GetService("Players").LocalPlayer
local char = plr.Character or plr.CharacterAdded
local root = char.HumanoidRootPart
local humanoid = char.Humanoid
local pos = Instance.new("BodyPosition")
local gyro = Instance.new("BodyGyro")
local run = game:GetService("RunService")
local cam = workspace.CurrentCamera
local dir
local cf
local dir
local direction
pos.Position = root.Position
pos.MaxForce = Vector3.new(math.huge, math.huge, math.huge)
pos.P = 100000
pos.D = 1750
pos.Parent = root
gyro.MaxTorque = Vector3.new(math.huge, math.huge, math.huge)
gyro.P = 100000
gyro.D = 2200
gyro.Parent = root
humanoid.PlatformStand = true

local speed = 1

local event = run.Heartbeat:Connect(function()
    cf = cam.CFrame.Rotation
    dir = cf:VectorToObjectSpace(humanoid.MoveDirection * speed)
    if dir.Magnitude == 0 then
        direction = Vector3.new(0,0,0)
    else
        direction = cf:VectorToWorldSpace(Vector3.new(dir.X, 0, dir.Z).Unit * dir.Magnitude)
    end
    pos.Position = pos.Position + direction
    gyro.CFrame = cam.CFrame
    for i, o in pairs(char:GetChildren()) do
        if o:IsA("BasePart") then
            o.CanCollide = false
        end
    end
    humanoid.PlatformStand = true
end)

game:GetService("UserInputService").JumpRequest:Connect(function()
    event:Disconnect()
    pos:Destroy()
    gyro:Destroy()
    humanoid.PlatformStand = false
end)