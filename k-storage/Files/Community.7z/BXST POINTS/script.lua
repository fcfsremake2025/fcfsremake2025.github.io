-- Assuming you're using leaderstats to track points

-- Function to give points to a player
local function givePoints(player, amount)
    local leaderstats = player:FindFirstChild("leaderstats")
    if leaderstats then
        local points = leaderstats:FindFirstChild("Points")
        if points then
            points.Value = points.Value + amount
        end
    end
end

-- Example: Give 10,000 points to a specific player by name
local Players = game:GetService("Players")

local targetPlayerName = "YourUsernameHere" -- replace with your in-game name
local amountToGive = 10000

local player = Players:FindFirstChild(targetPlayerName)
if player then
    givePoints(player, amountToGive)
end