while true do
local fruit = game:GetService(“ReplicatedStorage”).Remotes.GetFruit:InvokeServer()
if fruit == “Dragon” or fruit == “Leopard” or fruit == “Venom” or fruit == "Kitsune" or fruit =="Gas" or fruit == "Control"
print("got a rare fruit: " … fruit)
break
end
end