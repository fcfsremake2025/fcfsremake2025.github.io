loadstring([[
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Debris = game:GetService("Debris")

-- Create RemoteEvent if it doesn't exist
local remote = ReplicatedStorage:FindFirstChild("SelfDestruct")
if not remote then
    remote = Instance.new("RemoteEvent")
    remote.Name = "SelfDestruct"
    remote.Parent = ReplicatedStorage
end

-- Settings
local EXPLOSION_RADIUS = 15
local DAMAGE_AMOUNT = 100

remote.OnServerEvent:Connect(function(player)
    local character = player.Character
    if not character or not character:FindFirstChild("HumanoidRootPart") then return end

    local hrp = character.HumanoidRootPart

    -- Optional Explosion Sound
    local sound = Instance.new("Sound")
    sound.SoundId = "rbxassetid://138186576" -- explosion sound
    sound.Volume = 2
    sound.Parent = hrp
    sound:Play()
    Debris:AddItem(sound, 5)

    -- Optional Explosion Visual
    local explosion = Instance.new("Explosion")
    explosion.Position = hrp.Position
    explosion.BlastRadius = 0 -- purely visual
    explosion.BlastPressure = 0
    explosion.Parent = workspace
    Debris:AddItem(explosion, 3)

    -- Damage nearby players
    for _, otherPlayer in pairs(Players:GetPlayers()) do
        if otherPlayer ~= player and otherPlayer.Character and otherPlayer.Character:FindFirstChild("HumanoidRootPart") then
            local dist = (otherPlayer.Character.HumanoidRootPart.Position - hrp.Position).Magnitude
            if dist <= EXPLOSION_RADIUS then
                local hum = otherPlayer.Character:FindFirstChild("Humanoid")
                if hum then
                    hum:TakeDamage(DAMAGE_AMOUNT)
                end
            end
        end
    end

    -- Kill self
    local hum = character:FindFirstChild("Humanoid")
    if hum then
        hum.Health = 0
    end
end)
]])()