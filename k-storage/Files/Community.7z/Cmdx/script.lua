--[[----------------------------------------------------------------
|                ▄▀▄▄▄▄   ▄▀▀▄ ▄▀▄  ▄▀▀█▄▄   ▄▀▀▄  ▄▀▄             |
|               █ █    ▌ █  █ ▀  █ █ ▄▀   █ █    █   █             |
|              ▐ █      ▐  █    █ ▐ █    █ ▐     ▀▄▀               |
|                █        █    █    █    █      ▄▀ █               |
|               ▄▀▄▄▄▄▀ ▄▀   ▄▀    ▄▀▄▄▄▄▀     █  ▄▀               |
|              █     ▐  █    █    █     ▐    ▄▀  ▄▀                |
|              ▐        ▐    ▐    ▐         █    ▐                 |
|               ▐        ▐    ▐    ▐         █    ▐                |
|------------------------------------------------------------------|
|    Credits:    | Binds & Info:                                   |
|    pigeon#1818 | U                         Open and close output |
|        hz#4777 | RShift                          Fill suggestion |
|     Curvn#2646 | ;                               Focus on CMDBar |
| -------------- | Q                                Open and close |
|                | LShift+Bksp                        Clear CMDbar |
|                |                                                 |
|                | .cmds                             List commands |
----------------------------------------------------------------]]--
loadstring(game:HttpGet("https://raw.githubusercontent.com/CMD-X/CMD-X/master/Source",true))()
