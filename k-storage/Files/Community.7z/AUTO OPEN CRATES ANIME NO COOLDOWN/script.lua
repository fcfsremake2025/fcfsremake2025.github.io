while wait(0.1) do

local args = {
	{
		{
			"Anime",
			2
		},
		"E"
	}
}
game:GetService("ReplicatedStorage"):WaitForChild("BridgeNet2"):WaitForChild("dataRemoteEvent"):FireServer(unpack(args))
end