-- Arceus X compatible Lua script to create a simple kick GUI

local Players = game:GetService("Players")

local player = Players.LocalPlayer

local RunService = game:GetService("RunService")

-- Create ScreenGui

local screenGui = Instance.new("ScreenGui")

screenGui.Name = "KickGui"

screenGui.Parent = player:WaitForChild("PlayerGui")

-- Create Frame

local frame = Instance.new("Frame")

frame.Size = UDim2.new(0, 300, 0, 400)

frame.Position = UDim2.new(0.5, -150, 0.5, -200)

frame.BackgroundColor3 = Color3.fromRGB(30, 30, 30)

frame.Parent = screenGui

-- Title label

local title = Instance.new("TextLabel")

title.Size = UDim2.new(1, 0, 0, 30)

title.BackgroundTransparency = 1

title.Text = "Kick Player GUI"

title.TextColor3 = Color3.new(1, 1, 1)

title.Font = Enum.Font.SourceSansBold

title.TextSize = 20

title.Parent = frame

-- Player dropdown (simple list)

local playerListFrame = Instance.new("ScrollingFrame")

playerListFrame.Size = UDim2.new(1, -20, 0, 200)

playerListFrame.Position = UDim2.new(0, 10, 0, 40)

playerListFrame.CanvasSize = UDim2.new(0, 0, 0, 0)

playerListFrame.ScrollBarThickness = 8

playerListFrame.BackgroundColor3 = Color3.fromRGB(50, 50, 50)

playerListFrame.Parent = frame

-- UIListLayout for player list

local layout = Instance.new("UIListLayout")

layout.Parent = playerListFrame

layout.SortOrder = Enum.SortOrder.LayoutOrder

-- Selected player label

local selectedPlayerLabel = Instance.new("TextLabel")

selectedPlayerLabel.Size = UDim2.new(1, -20, 0, 30)

selectedPlayerLabel.Position = UDim2.new(0, 10, 0, 250)

selectedPlayerLabel.BackgroundColor3 = Color3.fromRGB(40, 40, 40)

selectedPlayerLabel.TextColor3 = Color3.new(1, 1, 1)

selectedPlayerLabel.Text = "Selected Player: None"

selectedPlayerLabel.Parent = frame

-- Reason TextBox

local reasonBox = Instance.new("TextBox")

reasonBox.Size = UDim2.new(1, -20, 0, 30)

reasonBox.Position = UDim2.new(0, 10, 0, 290)

reasonBox.PlaceholderText = "Enter kick reason (optional)"

reasonBox.BackgroundColor3 = Color3.fromRGB(40, 40, 40)

reasonBox.TextColor3 = Color3.new(1, 1, 1)

reasonBox.Parent = frame

-- Kick Button

local kickButton = Instance.new("TextButton")

kickButton.Size = UDim2.new(1, -20, 0, 40)

kickButton.Position = UDim2.new(0, 10, 0, 340)

kickButton.Text = "Kick Player"

kickButton.BackgroundColor3 = Color3.fromRGB(200, 50, 50)

kickButton.TextColor3 = Color3.new(1, 1, 1)

kickButton.Font = Enum.Font.SourceSansBold

kickButton.TextSize = 24

kickButton.Parent = frame

local selectedPlayer = nil

-- Function to refresh player list

local function refreshPlayerList()

    -- Clear old buttons

    for _, child in pairs(playerListFrame:GetChildren()) do

        if child:IsA("TextButton") then

            child:Destroy()

        end

    end

    

    -- Create new buttons for players

    for _, plr in pairs(Players:GetPlayers()) do

        local btn = Instance.new("TextButton")

        btn.Size = UDim2.new(1, -10, 0, 30)

        btn.Text = plr.Name

        btn.BackgroundColor3 = Color3.fromRGB(60, 60, 60)

        btn.TextColor3 = Color3.new(1,1,1)

        btn.Parent = playerListFrame

        

        btn.MouseButton1Click:Connect(function()

            selectedPlayer = plr

            selectedPlayerLabel.Text = "Selected Player: " .. plr.Name

        end)

    end

    

    -- Update CanvasSize for scrolling

    local layout = playerListFrame:FindFirstChildOfClass("UIListLayout")

    if layout then

        playerListFrame.CanvasSize = UDim2.new(0, 0, 0, layout.AbsoluteContentSize.Y + 10)

    end

end

refreshPlayerList()

-- Update player list when players join/leave

Players.PlayerAdded:Connect(refreshPlayerList)

Players.PlayerRemoving:Connect(refreshPlayerList)

-- Kick button action

kickButton.MouseButton1Click:Connect(function()

    if selectedPlayer then

        -- This only kicks local player if selected; kicking others requires server exploit or special remotes

        if selectedPlayer == player then

            player:Kick(reasonBox.Text ~= "" and reasonBox.Text or "You have been kicked.")

        else

            -- Try to find a RemoteEvent to kick others (example, change to your game's remote event)

            local rs = game:GetService("ReplicatedStorage")

            local kickEvent = rs:FindFirstChild("KickPlayerEvent")

            if kickEvent and kickEvent:IsA("RemoteEvent") then

                kickEvent:FireServer(selectedPlayer.Name, reasonBox.Text)

            else

                warn("No kick RemoteEvent found or no permission to kick others.")

            end

        end

    else

        warn("No player selected to kick.")

    end

end)

