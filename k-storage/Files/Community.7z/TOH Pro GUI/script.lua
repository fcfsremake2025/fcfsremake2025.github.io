--// TOWER OF HELL — PRO GUI (Game-Specific)
--// With scrolling tabs
--// Features: Speed & Jump sliders, Infinite Jump, Noclip, Kill-Part Shield, Teleport to End, ESP for top, Anti-AFK, Rainbow
 
--== SAFETY RESET ==--
pcall(function()
    if getgenv and getgenv().TOH_Pro then
        if getgenv().TOH_Pro.cleanup then getgenv().TOH_Pro.cleanup() end
    end
end)
 
local Players = game:GetService("Players")
local RS = game:GetService("RunService")
local UIS = game:GetService("UserInputService")
local VU = game:GetService("VirtualUser")
local LP = Players.LocalPlayer
 
local function char() return LP.Character or LP.CharacterAdded:Wait() end
local function hum() return char():FindFirstChildOfClass("Humanoid") end
local function hrp() return char():FindFirstChild("HumanoidRootPart") end
 
local S = { ws=16, jp=50, infiniteJump=false, noclip=false, shield=false, antiAfk=true, esp=false, conns={}, espObj=nil, ui=nil }
local alive=true
local function addconn(c) table.insert(S.conns,c) return c end
 
-- Kill any previous GUI
for _,g in ipairs(LP:WaitForChild("PlayerGui"):GetChildren()) do
    if g.Name=="TOH_ProGUI" then g:Destroy() end
end
 
--== UI BUILD ==--
local pg = Instance.new("ScreenGui")
pg.Name="TOH_ProGUI"; pg.ResetOnSpawn=false; pg.IgnoreGuiInset=true; pg.Parent=LP:WaitForChild("PlayerGui")
S.ui=pg
 
local main=Instance.new("Frame",pg)
main.Size=UDim2.new(0,460,0,290)
main.Position=UDim2.new(0.5,-230,0.3,0)
main.BackgroundColor3=Color3.fromRGB(24,24,28); main.BorderSizePixel=0
Instance.new("UICorner",main).CornerRadius=UDim.new(0,16)
 
local topbar=Instance.new("Frame",main)
topbar.Size=UDim2.new(1,0,0,36)
topbar.BackgroundColor3=Color3.fromRGB(30,30,36); topbar.BorderSizePixel=0
Instance.new("UICorner",topbar).CornerRadius=UDim.new(0,16)
 
local title=Instance.new("TextLabel",topbar)
title.Text="TOH • Pro Menu"; title.Font=Enum.Font.GothamBold; title.TextSize=16
title.TextColor3=Color3.fromRGB(230,230,235); title.BackgroundTransparency=1
title.Position=UDim2.new(0,14,0,0); title.Size=UDim2.new(0.5,0,1,0)
 
-- Dragging
do local dragging,dragStart,startPos
    addconn(topbar.InputBegan:Connect(function(input)
        if input.UserInputType==Enum.UserInputType.MouseButton1 then
            dragging=true; dragStart=input.Position; startPos=main.Position
            input.Changed:Connect(function() if input.UserInputState==Enum.UserInputState.End then dragging=false end end)
        end
    end))
    addconn(UIS.InputChanged:Connect(function(input)
        if dragging and input.UserInputType==Enum.UserInputType.MouseMovement then
            local delta=input.Position-dragStart
            main.Position=UDim2.new(startPos.X.Scale,startPos.X.Offset+delta.X,startPos.Y.Scale,startPos.Y.Offset+delta.Y)
        end
    end))
end
 
-- Tabs
local tabBar=Instance.new("Frame",main)
tabBar.BackgroundTransparency=1; tabBar.Size=UDim2.new(1,-20,0,32); tabBar.Position=UDim2.new(0,10,0,44)
local function mkTabButton(txt,x)
    local b=Instance.new("TextButton",tabBar)
    b.Text=txt; b.Font=Enum.Font.Gotham; b.TextSize=14
    b.TextColor3=Color3.fromRGB(230,230,235)
    b.BackgroundColor3=Color3.fromRGB(38,38,46); b.AutoButtonColor=true; b.BorderSizePixel=0
    b.Size=UDim2.new(0,110,1,0); b.Position=UDim2.new(0,x,0,0)
    Instance.new("UICorner",b).CornerRadius=UDim.new(0,10)
    return b
end
local tabs={ Movement=mkTabButton("Movement",0), Cheats=mkTabButton("Cheats",120), Visuals=mkTabButton("Visuals",240), Misc=mkTabButton("Misc",360)}
 
local container=Instance.new("Frame",main)
container.BackgroundTransparency=1; container.Size=UDim2.new(1,-20,1,-90); container.Position=UDim2.new(0,10,0,86)
 
-- Pages with scroll
local function mkPage()
    local sf=Instance.new("ScrollingFrame",container)
    sf.Size=UDim2.new(1,0,1,0); sf.BackgroundTransparency=1; sf.BorderSizePixel=0; sf.Visible=false
    sf.CanvasSize=UDim2.new(0,0,0,0); sf.ScrollBarThickness=6; sf.ScrollBarImageColor3=Color3.fromRGB(120,120,130)
    local layout=Instance.new("UIListLayout",sf); layout.Padding=UDim.new(0,12); layout.SortOrder=Enum.SortOrder.LayoutOrder
    layout:GetPropertyChangedSignal("AbsoluteContentSize"):Connect(function()
        sf.CanvasSize=UDim2.new(0,0,0,layout.AbsoluteContentSize.Y+12)
    end)
    return sf
end
local pages={ Movement=mkPage(), Cheats=mkPage(), Visuals=mkPage(), Misc=mkPage()}
 
--== FIX MISC TAB TO FIT GUI ==
pages.Misc.Size = UDim2.new(1,0,1,0)
pages.Misc.Position = UDim2.new(0,0,0,0)
 
local current="Movement"; pages[current].Visible=true
local function switch(tabName) for n,pg in pairs(pages) do pg.Visible=(n==tabName) end; current=tabName end
for name,btn in pairs(tabs) do addconn(btn.MouseButton1Click:Connect(function() switch(name) end)) end
 
-- UI Elements
local function mkSection(parent,label)
    local f=Instance.new("Frame",parent)
    f.Size=UDim2.new(1,-10,0,84); f.BackgroundColor3=Color3.fromRGB(30,30,36); f.BorderSizePixel=0
    Instance.new("UICorner",f).CornerRadius=UDim.new(0,12)
    local t=Instance.new("TextLabel",f)
    t.Text=label; t.Font=Enum.Font.GothamBold; t.TextSize=14; t.TextColor3=Color3.fromRGB(210,210,220)
    t.BackgroundTransparency=1; t.Position=UDim2.new(0,12,0,8); t.Size=UDim2.new(1,-24,0,18)
    return f
end
 
local function mkToggle(parent,label,default,cb)
    local holder=mkSection(parent,label)
    local text=Instance.new("TextLabel",holder); text.Text=label; text.Font=Enum.Font.Gotham; text.TextSize=14
    text.TextColor3=Color3.fromRGB(230,230,235); text.BackgroundTransparency=1; text.Position=UDim2.new(0,12,0,38); text.Size=UDim2.new(1,-70,0,20)
    local btn=Instance.new("TextButton",holder)
    btn.Text=default and "ON" or "OFF"; btn.Font=Enum.Font.GothamBold; btn.TextSize=14
    btn.TextColor3=default and Color3.fromRGB(60,255,120) or Color3.fromRGB(200,200,210)
    btn.BackgroundColor3=Color3.fromRGB(38,38,46); btn.BorderSizePixel=0
    btn.Size=UDim2.new(0,58,0,24); btn.Position=UDim2.new(1,-70,0,38)
    Instance.new("UICorner",btn).CornerRadius=UDim.new(0,8)
    local state=default; addconn(btn.MouseButton1Click:Connect(function()
        state=not state; btn.Text=state and "ON" or "OFF"; btn.TextColor3=state and Color3.fromRGB(60,255,120) or Color3.fromRGB(200,200,210); cb(state)
    end)); cb(default)
end
 
local function mkButton(parent,label,cb)
    local b=Instance.new("TextButton",parent)
    b.Text=label; b.Font=Enum.Font.GothamBold; b.TextSize=14; b.TextColor3=Color3.fromRGB(230,230,235)
    b.BackgroundColor3=Color3.fromRGB(38,38,46); b.BorderSizePixel=0; b.Size=UDim2.new(1,-10,0,36)
    Instance.new("UICorner",b).CornerRadius=UDim.new(0,10)
    addconn(b.MouseButton1Click:Connect(cb))
end
 
local function mkSlider(parent,label,min,max,default,cb)
    local sec=mkSection(parent,label.." ("..default..")")
    local bar=Instance.new("Frame",sec); bar.Size=UDim2.new(1,-24,0,6); bar.Position=UDim2.new(0,12,0,48)
    bar.BackgroundColor3=Color3.fromRGB(45,45,53); bar.BorderSizePixel=0; Instance.new("UICorner",bar).CornerRadius=UDim.new(0,4)
    local knob=Instance.new("Frame",bar); knob.Size=UDim2.new(0,12,0,18); knob.Position=UDim2.new((default-min)/(max-min),-6,0.5,-9)
    knob.BackgroundColor3=Color3.fromRGB(230,230,235); knob.BorderSizePixel=0; Instance.new("UICorner",knob).CornerRadius=UDim.new(0,6)
    local value=default; local dragging=false; local labelObj=sec:FindFirstChildOfClass("TextLabel")
    local function updateFromX(x) local rel=math.clamp((x-bar.AbsolutePosition.X)/bar.AbsoluteSize.X,0,1)
        value=math.floor(min+rel*(max-min)); knob.Position=UDim2.new(rel,-6,0.5,-9)
        labelObj.Text=string.format("%s (%d)",label,value); cb(value) end
    addconn(bar.InputBegan:Connect(function(input) if input.UserInputType==Enum.UserInputType.MouseButton1 then dragging=true; updateFromX(input.Position.X) end end))
    addconn(UIS.InputChanged:Connect(function(input) if dragging and input.UserInputType==Enum.UserInputType.MouseMovement then updateFromX(input.Position.X) end end))
    addconn(UIS.InputEnded:Connect(function(input) if input.UserInputType==Enum.UserInputType.MouseButton1 then dragging=false end end))
    cb(default)
end
 
--== MOVEMENT PAGE ==
mkSlider(pages.Movement,"WalkSpeed",10,120,32,function(v) S.ws=v end)
mkSlider(pages.Movement,"JumpPower",30,200,80,function(v) S.jp=v end)
mkToggle(pages.Movement,"Infinite Jump",false,function(on)
    S.infiniteJump=on
    if S.jumpCon then S.jumpCon:Disconnect(); S.jumpCon=nil end
    if on then S.jumpCon=addconn(UIS.JumpRequest:Connect(function() local h=hum(); if h then h:ChangeState(Enum.HumanoidStateType.Jumping) end end)) end
end)
 
--== CHEATS PAGE ==
mkToggle(pages.Cheats,"Noclip",false,function(on)
    S.noclip=on
    if S.noclipCon then S.noclipCon:Disconnect(); S.noclipCon=nil end
    if on then S.noclipCon=addconn(RS.Stepped:Connect(function() local c=char() for _,p in ipairs(c:GetDescendants()) do if p:IsA("BasePart") then p.CanCollide=false end end end)) end
end)
 
mkToggle(pages.Cheats,"Kill-Part Shield",false,function(on)
    S.shield=on
    if S.shieldCon then S.shieldCon:Disconnect(); S.shieldCon=nil end
    if on then S.shieldCon=addconn(hum().Touched:Connect(function(hit)
        if hit and (hit.Name:lower():find("kill") or hit.Name:lower():find("lava")) then local r=hrp() if r then r.CFrame=r.CFrame+Vector3.new(0,5,0) end end
    end)) end
end)
 
mkButton(pages.Cheats,"Teleport to End",function()
    local root=hrp(); if not root then return end
    local highestPart,highestY=nil,-1e9
    for _,d in ipairs(workspace:GetDescendants()) do
        if d:IsA("BasePart") and d.CanCollide and not d:IsDescendantOf(char()) then
            if d.Position.Y>highestY then highestY=d.Position.Y; highestPart=d end
        end
    end
    if highestPart then root.CFrame=CFrame.new(highestPart.Position+Vector3.new(0,8,0)) end
end)
 
--== VISUALS PAGE ==
mkToggle(pages.Visuals,"ESP Top",false,function(on)
    S.esp=on; if S.espObj then S.espObj:Destroy(); S.espObj=nil end
    if on then local hl=Instance.new("Highlight",pg); hl.FillTransparency=0.75; hl.OutlineColor=Color3.new(1,1,1); S.espObj=hl
        addconn(RS.Heartbeat:Connect(function()
            local hp,hy=nil,-1e9; for _,d in ipairs(workspace:GetDescendants()) do
                if d:IsA("BasePart") and d.CanCollide and not d:IsDescendantOf(char()) then if d.Position.Y>hy then hy=d.Position.Y; hp=d end end end
            if hp then hl.Adornee=hp end
        end))
    end
end)
 
mkToggle(pages.Visuals,"Rainbow Character",false,function(on)
    if S.rainbowCon then S.rainbowCon:Disconnect(); S.rainbowCon=nil end
    if on then local t=0; S.rainbowCon=addconn(RS.Heartbeat:Connect(function(dt) t+=dt; local c=Color3.fromHSV((t*0.1)%1,0.8,1)
        for _,p in ipairs(char():GetDescendants()) do if p:IsA("BasePart") and p.Name~="HumanoidRootPart" then p.Color=c end end end)) end
end)
 
--== MISC PAGE ==
mkToggle(pages.Misc,"Anti-AFK",true,function(on)
    S.antiAfk=on
    if S.antiAfkCon then S.antiAfkCon:Disconnect(); S.antiAfkCon=nil end
    if on then S.antiAfkCon=addconn(LP.Idled:Connect(function() VU:Button2Down(Vector2.new(0,0),workspace.CurrentCamera.CFrame); task.wait(0.1); VU:Button2Up(Vector2.new(0,0),workspace.CurrentCamera.CFrame) end)) end
end)
 
mkButton(pages.Misc,"Reset Character",function() local h=hum(); if h then h.Health=0 end end)
mkButton(pages.Misc,"Rejoin Server",function() game:GetService("TeleportService"):Teleport(game.PlaceId,LP) end)
 
--== CORE LOOPS ==--
addconn(RS.Heartbeat:Connect(function() local h=hum(); if h then pcall(function() h.WalkSpeed=S.ws; h.JumpPower=S.jp; h.UseJumpPower=true end) end end))
 
-- Cleanup
local function cleanup() alive=false; for _,c in ipairs(S.conns) do pcall(function() c:Disconnect() end) end; if S.espObj then S.espObj:Destroy() end; if S.ui then S.ui:Destroy() end end
if getgenv then getgenv().TOH_Pro={cleanup=cleanup} end
 
game:GetService("StarterGui"):SetCore("SendNotification",{Title="TOH Pro Menu",Text="Loaded with scrolling tabs",Duration=6})