-- Auto Wood Collector Script
loadstring(game:HttpGet("https://raw.githubusercontent.com/99nightsscripts/main/autowoodv2.lua"))()

-- Alternative method
local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local player = Players.LocalPlayer

local function collectWood()
    for _, obj in pairs(workspace:GetDescendants()) do
        if obj.Name == "Wood" and obj:IsA("Part") then
            player.Character.HumanoidRootPart.CFrame = obj.CFrame
            wait(0.1)
            fireproximityprompt(obj.ProximityPrompt)
            wait(0.5)
        end
    end
end

-- Auto collect every 30 seconds
spawn(function()
    while wait(30) do
        collectWood()
    end
end)