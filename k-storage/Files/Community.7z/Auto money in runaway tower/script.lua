-- Create ScreenGui with ResetOnSpawn = false for persistence
local screenGui = Instance.new("ScreenGui")
screenGui.Name = "ScriptGUI"
screenGui.ResetOnSpawn = false
screenGui.Parent = game.Players.LocalPlayer:WaitForChild("PlayerGui")

-- Variables for auto mode
local autoMode = false
local autoCooldown = 0.1
local autoConnection = nil
local RunService = game:GetService("RunService")
local TweenService = game:GetService("TweenService")
local UserInputService = game:GetService("UserInputService")

-- Main Frame
local mainFrame = Instance.new("Frame")
mainFrame.Name = "MainFrame"
mainFrame.Size = UDim2.new(0, 500, 0, 400)
mainFrame.Position = UDim2.new(0.5, -250, 0.5, -200)
mainFrame.BackgroundColor3 = Color3.fromRGB(45, 45, 45)
mainFrame.BorderSizePixel = 0
mainFrame.Active = true
mainFrame.Draggable = true
mainFrame.Parent = screenGui

-- Add rounded corners
local corner = Instance.new("UICorner")
corner.CornerRadius = UDim.new(0, 8)
corner.Parent = mainFrame

-- Title Bar
local titleBar = Instance.new("Frame")
titleBar.Name = "TitleBar"
titleBar.Size = UDim2.new(1, 0, 0, 40)
titleBar.Position = UDim2.new(0, 0, 0, 0)
titleBar.BackgroundColor3 = Color3.fromRGB(35, 35, 35)
titleBar.BorderSizePixel = 0
titleBar.Parent = mainFrame

-- Title bar rounded corners
local titleCorner = Instance.new("UICorner")
titleCorner.CornerRadius = UDim.new(0, 8)
titleCorner.Parent = titleBar

-- Title Text
local titleText = Instance.new("TextLabel")
titleText.Name = "TitleText"
titleText.Size = UDim2.new(1, -50, 1, 0)
titleText.Position = UDim2.new(0, 15, 0, 0)
titleText.BackgroundTransparency = 1
titleText.Text = "Script"
titleText.TextColor3 = Color3.fromRGB(255, 255, 255)
titleText.TextSize = 18
titleText.TextXAlignment = Enum.TextXAlignment.Left
titleText.Font = Enum.Font.SourceSansBold
titleText.Parent = titleBar

-- Close Button
local closeButton = Instance.new("TextButton")
closeButton.Name = "CloseButton"
closeButton.Size = UDim2.new(0, 40, 0, 40)
closeButton.Position = UDim2.new(1, -40, 0, 0)
closeButton.BackgroundColor3 = Color3.fromRGB(255, 85, 85)
closeButton.BorderSizePixel = 0
closeButton.Text = "×"
closeButton.TextColor3 = Color3.fromRGB(255, 255, 255)
closeButton.TextSize = 24
closeButton.Font = Enum.Font.SourceSansBold
closeButton.Parent = titleBar

-- Close button rounded corners
local closeCorner = Instance.new("UICorner")
closeCorner.CornerRadius = UDim.new(0, 8)
closeCorner.Parent = closeButton

-- Content Area
local contentFrame = Instance.new("Frame")
contentFrame.Name = "ContentFrame"
contentFrame.Size = UDim2.new(1, -30, 1, -70)
contentFrame.Position = UDim2.new(0, 15, 0, 55)
contentFrame.BackgroundTransparency = 1
contentFrame.Parent = mainFrame

-- Sample Content
local sampleText = Instance.new("TextLabel")
sampleText.Name = "SampleText"
sampleText.Size = UDim2.new(1, 0, 0, 40)
sampleText.Position = UDim2.new(0, 0, 0, 0)
sampleText.BackgroundTransparency = 1
sampleText.Text = "Click the button to activate the chest prompt!"
sampleText.TextColor3 = Color3.fromRGB(200, 200, 200)
sampleText.TextSize = 16
sampleText.Font = Enum.Font.SourceSans
sampleText.TextWrapped = true
sampleText.Parent = contentFrame

-- Manual Chest Button
local chestButton = Instance.new("TextButton")
chestButton.Name = "ChestButton"
chestButton.Size = UDim2.new(0, 200, 0, 40)
chestButton.Position = UDim2.new(0.5, -100, 0, 50)
chestButton.BackgroundColor3 = Color3.fromRGB(85, 170, 255)
chestButton.BorderSizePixel = 0
chestButton.Text = "Activate Chest"
chestButton.TextColor3 = Color3.fromRGB(255, 255, 255)
chestButton.TextSize = 16
chestButton.Font = Enum.Font.SourceSansBold
chestButton.Parent = contentFrame

-- Manual button rounded corners
local chestCorner = Instance.new("UICorner")
chestCorner.CornerRadius = UDim.new(0, 8)
chestCorner.Parent = chestButton

-- Auto Mode Toggle Button
local autoToggleButton = Instance.new("TextButton")
autoToggleButton.Name = "AutoToggleButton"
autoToggleButton.Size = UDim2.new(0, 200, 0, 40)
autoToggleButton.Position = UDim2.new(0.5, -100, 0, 100)
autoToggleButton.BackgroundColor3 = Color3.fromRGB(255, 85, 85)
autoToggleButton.BorderSizePixel = 0
autoToggleButton.Text = "Auto Mode: OFF"
autoToggleButton.TextColor3 = Color3.fromRGB(255, 255, 255)
autoToggleButton.TextSize = 16
autoToggleButton.Font = Enum.Font.SourceSansBold
autoToggleButton.Parent = contentFrame

-- Auto toggle button rounded corners
local autoCorner = Instance.new("UICorner")
autoCorner.CornerRadius = UDim.new(0, 8)
autoCorner.Parent = autoToggleButton

-- Cooldown Label
local cooldownLabel = Instance.new("TextLabel")
cooldownLabel.Name = "CooldownLabel"
cooldownLabel.Size = UDim2.new(1, 0, 0, 30)
cooldownLabel.Position = UDim2.new(0, 0, 0, 150)
cooldownLabel.BackgroundTransparency = 1
cooldownLabel.Text = "Cooldown: " .. autoCooldown .. " seconds"
cooldownLabel.TextColor3 = Color3.fromRGB(200, 200, 200)
cooldownLabel.TextSize = 14
cooldownLabel.Font = Enum.Font.SourceSans
cooldownLabel.Parent = contentFrame

-- Cooldown Slider Background
local sliderBG = Instance.new("Frame")
sliderBG.Name = "SliderBG"
sliderBG.Size = UDim2.new(0, 300, 0, 20)
sliderBG.Position = UDim2.new(0.5, -150, 0, 180)
sliderBG.BackgroundColor3 = Color3.fromRGB(60, 60, 60)
sliderBG.BorderSizePixel = 0
sliderBG.Active = true
sliderBG.Parent = contentFrame

-- Slider background rounded corners
local sliderBGCorner = Instance.new("UICorner")
sliderBGCorner.CornerRadius = UDim.new(0, 10)
sliderBGCorner.Parent = sliderBG

-- Cooldown Slider Fill
local sliderFill = Instance.new("Frame")
sliderFill.Name = "SliderFill"
sliderFill.Size = UDim2.new(0.1, 0, 1, 0)
sliderFill.Position = UDim2.new(0, 0, 0, 0)
sliderFill.BackgroundColor3 = Color3.fromRGB(85, 170, 255)
sliderFill.BorderSizePixel = 0
sliderFill.Parent = sliderBG

-- Slider fill rounded corners
local sliderFillCorner = Instance.new("UICorner")
sliderFillCorner.CornerRadius = UDim.new(0, 10)
sliderFillCorner.Parent = sliderFill

-- Cooldown Slider Button
local sliderButton = Instance.new("TextButton")
sliderButton.Name = "SliderButton"
sliderButton.Size = UDim2.new(0, 20, 0, 20)
sliderButton.Position = UDim2.new(0.1, -10, 0, 0)
sliderButton.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
sliderButton.BorderSizePixel = 0
sliderButton.Text = ""
sliderButton.Active = true
sliderButton.Parent = sliderBG

-- Slider button rounded corners
local sliderButtonCorner = Instance.new("UICorner")
sliderButtonCorner.CornerRadius = UDim.new(0, 10)
sliderButtonCorner.Parent = sliderButton

-- Status Label
local statusLabel = Instance.new("TextLabel")
statusLabel.Name = "StatusLabel"
statusLabel.Size = UDim2.new(1, 0, 0, 30)
statusLabel.Position = UDim2.new(0, 0, 0, 220)
statusLabel.BackgroundTransparency = 1
statusLabel.Text = "Ready"
statusLabel.TextColor3 = Color3.fromRGB(100, 255, 100)
statusLabel.TextSize = 16
statusLabel.Font = Enum.Font.SourceSans
statusLabel.Parent = contentFrame

-- Auto Status Label
local autoStatusLabel = Instance.new("TextLabel")
autoStatusLabel.Name = "AutoStatusLabel"
autoStatusLabel.Size = UDim2.new(1, 0, 0, 30)
autoStatusLabel.Position = UDim2.new(0, 0, 0, 250)
autoStatusLabel.BackgroundTransparency = 1
autoStatusLabel.Text = "Auto Mode: Inactive"
autoStatusLabel.TextColor3 = Color3.fromRGB(200, 200, 200)
autoStatusLabel.TextSize = 14
autoStatusLabel.Font = Enum.Font.SourceSans
autoStatusLabel.Parent = contentFrame

-- Functions
local function fireChestPrompt()
    local chestPrompt = workspace:FindFirstChild("Chest_Prompt")
    
    if chestPrompt then
        local proximityPrompt = chestPrompt:FindFirstChildOfClass("ProximityPrompt")
        
        if proximityPrompt then
            fireproximityprompt(proximityPrompt)
            statusLabel.Text = "Chest prompt activated!"
            statusLabel.TextColor3 = Color3.fromRGB(100, 255, 100)
            return true
        else
            statusLabel.Text = "ProximityPrompt not found!"
            statusLabel.TextColor3 = Color3.fromRGB(255, 100, 100)
            return false
        end
    else
        statusLabel.Text = "Chest_Prompt part not found!"
        statusLabel.TextColor3 = Color3.fromRGB(255, 100, 100)
        return false
    end
end

local function startAutoMode()
    if autoConnection then
        autoConnection:Disconnect()
    end
    
    autoConnection = RunService.Heartbeat:Connect(function()
        if autoMode then
            fireChestPrompt()
            autoStatusLabel.Text = "Auto Mode: Active (Cooldown: " .. autoCooldown .. "s)"
            wait(autoCooldown)
        end
    end)
end

local function stopAutoMode()
    if autoConnection then
        autoConnection:Disconnect()
        autoConnection = nil
    end
    autoStatusLabel.Text = "Auto Mode: Inactive"
end

local function toggleAutoMode()
    autoMode = not autoMode
    
    if autoMode then
        autoToggleButton.Text = "Auto Mode: ON"
        autoToggleButton.BackgroundColor3 = Color3.fromRGB(85, 255, 85)
        sampleText.Text = "Auto mode is active! Chest will activate every " .. autoCooldown .. " seconds."
        startAutoMode()
    else
        autoToggleButton.Text = "Auto Mode: OFF"
        autoToggleButton.BackgroundColor3 = Color3.fromRGB(255, 85, 85)
        sampleText.Text = "Auto mode is disabled. Click button to activate manually."
        stopAutoMode()
    end
end

-- Fixed Slider functionality
local dragging = false

local function updateSlider(mouseX)
    local relativeX = mouseX - sliderBG.AbsolutePosition.X
    local relativePos = math.clamp(relativeX / sliderBG.AbsoluteSize.X, 0, 1)
    
    -- Calculate cooldown between 0.01 and 1.00 seconds
    autoCooldown = math.round((0.01 + (relativePos * 0.99)) * 100) / 100
    
    -- Update visual elements
    sliderFill.Size = UDim2.new(relativePos, 0, 1, 0)
    sliderButton.Position = UDim2.new(relativePos, -10, 0, 0)
    cooldownLabel.Text = "Cooldown: " .. autoCooldown .. " seconds"
    
    -- Update auto mode if it's active
    if autoMode then
        sampleText.Text = "Auto mode is active! Chest will activate every " .. autoCooldown .. " seconds."
        startAutoMode() -- Restart with new cooldown
    end
end

-- Close function
local function closeGUI()
    if autoConnection then
        autoConnection:Disconnect()
    end
    screenGui:Destroy()
end

-- Connect button events
closeButton.MouseButton1Click:Connect(closeGUI)
chestButton.MouseButton1Click:Connect(fireChestPrompt)
autoToggleButton.MouseButton1Click:Connect(toggleAutoMode)

-- Fixed Slider events
sliderButton.MouseButton1Down:Connect(function()
    dragging = true
end)

-- Handle mouse movement while dragging
local function onMouseMove(input)
    if dragging and input.UserInputType == Enum.UserInputType.MouseMovement then
        updateSlider(input.Position.X)
    end
end

-- Handle mouse release
local function onMouseUp(input)
    if input.UserInputType == Enum.UserInputType.MouseButton1 and dragging then
        dragging = false
    end
end

-- Connect mouse events
UserInputService.InputChanged:Connect(onMouseMove)
UserInputService.InputEnded:Connect(onMouseUp)

-- Click anywhere on slider background to set position
sliderBG.MouseButton1Click:Connect(function()
    local mouse = game.Players.LocalPlayer:GetMouse()
    updateSlider(mouse.X)
end)

-- Hover effects
closeButton.MouseEnter:Connect(function()
    closeButton.BackgroundColor3 = Color3.fromRGB(255, 120, 120)
end)

closeButton.MouseLeave:Connect(function()
    closeButton.BackgroundColor3 = Color3.fromRGB(255, 85, 85)
end)

chestButton.MouseEnter:Connect(function()
    chestButton.BackgroundColor3 = Color3.fromRGB(100, 180, 255)
end)

chestButton.MouseLeave:Connect(function()
    chestButton.BackgroundColor3 = Color3.fromRGB(85, 170, 255)
end)

autoToggleButton.MouseEnter:Connect(function()
    if autoMode then
        autoToggleButton.BackgroundColor3 = Color3.fromRGB(120, 255, 120)
    else
        autoToggleButton.BackgroundColor3 = Color3.fromRGB(255, 120, 120)
    end
end)

autoToggleButton.MouseLeave:Connect(function()
    if autoMode then
        autoToggleButton.BackgroundColor3 = Color3.fromRGB(85, 255, 85)
    else
        autoToggleButton.BackgroundColor3 = Color3.fromRGB(255, 85, 85)
    end
end)

-- Slider button hover effects
sliderButton.MouseEnter:Connect(function()
    sliderButton.BackgroundColor3 = Color3.fromRGB(230, 230, 230)
end)

sliderButton.MouseLeave:Connect(function()
    sliderButton.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
end)

print("Script GUI loaded successfully with working slider!")
