--[[  
WARNING: Heads up! This script has not been verified. Use at your own risk!  
]]  
local TweenService = game:GetService("TweenService")  
local Players = game:GetService("Players")  
local UserInputService = game:GetService("UserInputService")  
local fruitNames = {"apple","cactus","candy blossom","coconut","dragon fruit","easter egg","grape","mango","peach","pineapple","blue berry"}  
local activeTweens = {}  

local function createRainbowTween(label)  
  local colors = {Color3.new(1,0,0),Color3.new(1,0.5,0),Color3.new(1,1,0),Color3.new(0,1,0),Color3.new(0,0,1),Color3.new(0.5,0,1),Color3.new(1,0,1)}  
  local tweenInfo = TweenInfo.new(1,Enum.EasingStyle.Linear)  
  if activeTweens[label] then activeTweens[label]:Cancel(); activeTweens[label]=nil end  
  spawn(function()  
    while true do  
      for _,c in ipairs(colors) do  
        local tw = TweenService:Create(label,tweenInfo,{TextColor3=c})  
        activeTweens[label]=tw; tw:Play(); tw.Completed:Wait()  
      end  
    end  
  end)  
end  

local function updateFruits()  
  for _,fruit in pairs(workspace:GetDescendants()) do  
    if table.find(fruitNames,fruit.Name:lower()) then  
      local w=fruit:FindFirstChild("Weight")  
      local v=fruit:FindFirstChild("Variant")  
      if w and w:IsA("NumberValue") then  
        local val=math.floor(w.Value)  
        local var=(v and v:IsA("StringValue") and v.Value) or "Normal"  
        local show=(fruit.Name:lower()=="blue berry") or var=="Gold" or var=="Rainbow" or w.Value>20  
        local col=(var=="Gold" and Color3.new(1,1,0)) or Color3.new(0,0,1)  
        if show then  
          local bb=fruit:FindFirstChild("WeightDisplay")  
          local md=50+(val*2)  
          if not bb then  
            bb=Instance.new("BillboardGui"); bb.Name="WeightDisplay"; bb.Parent=fruit  
            bb.Adornee=fruit; bb.Size=UDim2.new(0,100,0,50); bb.MaxDistance=md; bb.StudsOffset=Vector3.new(0,2,0); bb.AlwaysOnTop=true  
            local fr=Instance.new("Frame"); fr.Parent=bb; fr.Size=UDim2.new(1,0,1,0); fr.BackgroundTransparency=1  
            local sl=Instance.new("TextLabel"); sl.Name="ShadowLabel"; sl.Parent=fr; sl.Position=UDim2.new(0,2,0,2)  
            sl.Size=UDim2.new(1,-2,0.7,-2); sl.BackgroundTransparency=1; sl.TextColor3=Color3.new(0.5,0.5,0.5)  
            sl.TextScaled=true; sl.Text=tostring(val)  
            local ml=Instance.new("TextLabel"); ml.Name="MainLabel"; ml.Parent=fr; ml.Position=UDim2.new(0,0,0,0)  
            ml.Size=UDim2.new(1,0,0.7,0); ml.BackgroundTransparency=1; ml.TextColor3=col; ml.TextScaled=true; ml.Text=tostring(val)  
            local vl=Instance.new("TextLabel"); vl.Name="VariantLabel"; vl.Parent=fr; vl.Position=UDim2.new(0,0,0.7,0)  
            vl.Size=UDim2.new(1,0,0.3,0); vl.BackgroundTransparency=1; vl.TextColor3=col  
            vl.TextScaled=true; vl.Text=var~="Normal" and var or ""  
            bb.Destroying:Connect(function() if activeTweens[ml] then activeTweens[ml]:Cancel() end if activeTweens[vl] then activeTweens[vl]:Cancel() end end)  
            if var=="Rainbow" then createRainbowTween(ml); createRainbowTween(vl) end  
          else  
            bb.MaxDistance=md  
          end  
        else  
          local bb=fruit:FindFirstChild("WeightDisplay")  
          if bb then bb:Destroy() end  
        end  
      end  
    end  
  end  
end  

local gui=Instance.new("ScreenGui",Players.LocalPlayer.PlayerGui)  
local btn=Instance.new("TextButton",gui)  
btn.Size=UDim2.new(0,50,0,50); btn.Position=UDim2.new(0,10,0,10); btn.BackgroundColor3=Color3.new(0,0,1); btn.Text=""  
btn.MouseButton1Click:Connect(updateFruits)  
updateFruits()