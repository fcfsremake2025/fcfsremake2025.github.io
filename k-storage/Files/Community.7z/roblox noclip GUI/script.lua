local player = game.Players.LocalPlayer
local UIS = game:GetService("UserInputService")
local RunService = game:GetService("RunService")


if game.CoreGui:FindFirstChild("NoclipGui") then
    return
end

local noclipEnabled = false


local screenGui = Instance.new("ScreenGui", game.CoreGui)
screenGui.Name = "NoclipGui"
screenGui.ResetOnSpawn = false


local function enableDragging(gui)
    local dragging = false
    local dragInput, dragStart, startPos

    gui.InputBegan:Connect(function(input)
        if input.UserInputType == Enum.UserInputType.MouseButton1 then
            dragging = true
            dragStart = input.Position
            startPos = gui.Position

            input.Changed:Connect(function()
                if input.UserInputState == Enum.UserInputState.End then
                    dragging = false
                end
            end)
        end
    end)

    gui.InputChanged:Connect(function(input)
        if input.UserInputType == Enum.UserInputType.MouseMovement then
            dragInput = input
        end
    end)

    UIS.InputChanged:Connect(function(input)
        if input == dragInput and dragging then
            local delta = input.Position - dragStart
            gui.Position = UDim2.new(startPos.X.Scale, startPos.X.Offset + delta.X,
                                     startPos.Y.Scale, startPos.Y.Offset + delta.Y)
        end
    end)
end


local toggleUIBtn = Instance.new("TextButton", screenGui)
toggleUIBtn.Size = UDim2.new(0, 100, 0, 30)
toggleUIBtn.Position = UDim2.new(0, 10, 0, 10)
toggleUIBtn.BackgroundColor3 = Color3.fromRGB(50, 50, 50)
toggleUIBtn.TextColor3 = Color3.new(1, 1, 1)
toggleUIBtn.Text = " Noclip"
toggleUIBtn.Font = Enum.Font.SourceSansBold
toggleUIBtn.TextScaled = true
toggleUIBtn.Active = true

enableDragging(toggleUIBtn)


local noclipBtn = Instance.new("TextButton", screenGui)
noclipBtn.Size = UDim2.new(0, 120, 0, 40)
noclipBtn.Position = UDim2.new(0, 10, 0, 50)
noclipBtn.BackgroundColor3 = Color3.fromRGB(100, 30, 30)
noclipBtn.TextColor3 = Color3.new(1, 1, 1)
noclipBtn.Text = "Noclip : OFF"
noclipBtn.Font = Enum.Font.SourceSansBold
noclipBtn.TextScaled = true
noclipBtn.Active = true

enableDragging(noclipBtn)


local function setNoclip(state)
    noclipEnabled = state
    noclipBtn.Text = "Noclip : " .. (state and "ON" or "OFF")
    noclipBtn.BackgroundColor3 = state and Color3.fromRGB(30, 100, 30) or Color3.fromRGB(100, 30, 30)
end


RunService.Stepped:Connect(function()
    if noclipEnabled then
        local char = player.Character
        if char then
            for _, part in pairs(char:GetDescendants()) do
                if part:IsA("BasePart") and part.CanCollide then
                    part.CanCollide = false
                end
            end
        end
    end
end)


noclipBtn.MouseButton1Click:Connect(function()
    setNoclip(not noclipEnabled)
end)


toggleUIBtn.MouseButton1Click:Connect(function()
    noclipBtn.Visible = not noclipBtn.Visible
end)


player.CharacterAdded:Connect(function(char)
    char:WaitForChild("HumanoidRootPart", 5)
    if noclipEnabled then
        task.wait(0.1)
        for _, part in pairs(char:GetDescendants()) do
            if part:IsA("BasePart") then
                part.CanCollide = false
            end
        end
    end
end)