local Players = game:GetService("Players")
local LocalPlayer = Players.LocalPlayer
local UserInputService = game:GetService("UserInputService")

-- Make a GUI to show chat logs
local ScreenGui = Instance.new("ScreenGui", game.CoreGui)
local Frame = Instance.new("Frame", ScreenGui)
Frame.Position = UDim2.new(0.7, 0, 0.1, 0)
Frame.Size = UDim2.new(0, 300, 0, 400)
Frame.BackgroundColor3 = Color3.fromRGB(30, 30, 30)
Frame.BorderSizePixel = 0

-- Manual dragging support
local dragging, dragInput, dragStart, startPos

Frame.InputBegan:Connect(function(input)
	if input.UserInputType == Enum.UserInputType.MouseButton1 then
		dragging = true
		dragStart = input.Position
		startPos = Frame.Position

		input.Changed:Connect(function()
			if input.UserInputState == Enum.UserInputState.End then
				dragging = false
			end
		end)
	end
end)

Frame.InputChanged:Connect(function(input)
	if input.UserInputType == Enum.UserInputType.MouseMovement then
		dragInput = input
	end
end)

UserInputService.InputChanged:Connect(function(input)
	if input == dragInput and dragging then
		local delta = input.Position - dragStart
		Frame.Position = UDim2.new(
			startPos.X.Scale, startPos.X.Offset + delta.X,
			startPos.Y.Scale, startPos.Y.Offset + delta.Y
		)
	end
end)

-- Vertical + horizontal scrolling chat log area
local ScrollingFrame = Instance.new("ScrollingFrame", Frame)
ScrollingFrame.Size = UDim2.new(1, 0, 1, 0)
ScrollingFrame.CanvasSize = UDim2.new(2, 0, 10, 0) -- Start wide and tall
ScrollingFrame.ScrollBarThickness = 4
ScrollingFrame.ScrollingDirection = Enum.ScrollingDirection.XY
ScrollingFrame.BackgroundTransparency = 1

local UIListLayout = Instance.new("UIListLayout", ScrollingFrame)
UIListLayout.SortOrder = Enum.SortOrder.LayoutOrder

-- Dynamically update CanvasSize Y based on content height
UIListLayout:GetPropertyChangedSignal("AbsoluteContentSize"):Connect(function()
	ScrollingFrame.CanvasSize = UDim2.new(
		2, 0, -- horizontal size fixed at 2x width for horizontal scroll
		0, UIListLayout.AbsoluteContentSize.Y + 10 -- add a small padding vertically
	)
end)

-- Chat function (simple labels, scrolls if too wide)
local function spyMessage(plr, msg)
	if plr == LocalPlayer then return end

	local label = Instance.new("TextLabel", ScrollingFrame)
	label.Size = UDim2.new(0, 1000, 0, 20) -- wide for horizontal scroll
	label.TextXAlignment = Enum.TextXAlignment.Left
	label.BackgroundTransparency = 1
	label.TextColor3 = Color3.new(1, 1, 1)
	label.Font = Enum.Font.SourceSans
	label.TextSize = 14
	label.Text = "[" .. plr.Name .. "]: " .. msg
end

-- Hook into all current players
for _, player in ipairs(Players:GetPlayers()) do
	player.Chatted:Connect(function(msg)
		spyMessage(player, msg)
	end)
end

-- Detect new players
Players.PlayerAdded:Connect(function(player)
	player.Chatted:Connect(function(msg)
		spyMessage(player, msg)
	end)
end)