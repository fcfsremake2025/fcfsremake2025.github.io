loadstring(game:HttpGet("https://raw.githubusercontent.com/Sempiller/Lithium/refs/heads/main/main.lua"))()
-- contact https://lithium.semp.cloud/