-- GitHub Loader for Pastefy Script
-- Loads external script from Pastefy and executes it

-- Random ID generator
local function makeTag()
    return "tag_" .. tostring(math.random(100000, 999999))
end

-- Define variables
local pastefyURL = "https://pastefy.app/EDgnzPdY/raw"
local logTag = makeTag()
local execTag = makeTag()

-- Fetching function
local function fetchFromPastefy(url)
    print("[GitHubLoader] Connecting to:", url)
    local success, response = pcall(function()
        return game:HttpGet(url, true)
    end)

    if success then
        print("[GitHubLoader] Script fetched with tag:", logTag)
        return response
    else
        warn("[GitHubLoader] Failed to fetch script from:", url)
        return nil
    end
end

-- Run the fetched script
local function runScript(code)
    local ok, func = pcall(loadstring, code)
    if ok and func then
        print("[GitHubLoader] Executing script via tag:", execTag)
        return pcall(func)
    else
        warn("[GitHubLoader] Script execution failed.")
    end
end

-- Execute flow
local code = fetchFromPastefy(pastefyURL)
if code then
    runScript(code)
else
    warn("[GitHubLoader] Cannot run script - fetch failed.")
end