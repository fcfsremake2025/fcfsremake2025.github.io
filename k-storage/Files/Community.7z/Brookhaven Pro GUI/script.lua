--// BROOKHAVEN — PRO GUI (Game-Specific)
--// Tabs: Movement, Teleport, Visuals, Misc
--// Features: WalkSpeed/JumpPower sliders, Fly, Noclip, TP-to-player, Follow target, Player ESP, Night Vision, Anti-AFK, Rejoin
--// Notes: Some actions are client-side; game updates can break things. Use at your own risk.

--== SAFETY RESET ==--
pcall(function()
    if getgenv and getgenv().BH_Pro then
        if getgenv().BH_Pro.cleanup then getgenv().BH_Pro.cleanup() end
    end
end)

--== SERVICES ==--
local Players = game:GetService("Players")
local RS = game:GetService("RunService")
local UIS = game:GetService("UserInputService")
local VU  = game:GetService("VirtualUser")
local TS  = game:GetService("TeleportService")
local Lighting = game:GetService("Lighting")
local LP = Players.LocalPlayer

local function char() return LP.Character or LP.CharacterAdded:Wait() end
local function hum() return char():FindFirstChildOfClass("Humanoid") end
local function hrp() return char():FindFirstChild("HumanoidRootPart") end

--== STATE ==--
local S = {
    ws = 16, jp = 50,
    fly = false, flySpeed = 60, flyBV=nil, flyBG=nil,
    noclip = false,
    antiAfk = true,
    esp = false, espFolder=nil,
    nightVision = false, cc=nil, bloom=nil, exp=nil,
    follow = false, followTarget = nil,
    conns = {},
    ui = nil
}

local function addconn(c) table.insert(S.conns, c) return c end
local function notify(t, txt, dur) pcall(function()
    game:GetService("StarterGui"):SetCore("SendNotification",{Title=t,Text=txt,Duration=dur or 5})
end) end

--== CLEAN OLD GUI ==--
for _,g in ipairs(LP:WaitForChild("PlayerGui"):GetChildren()) do
    if g.Name == "BH_ProGUI" then g:Destroy() end
end

--== UI BUILD ==--
local pg = Instance.new("ScreenGui")
pg.Name = "BH_ProGUI"
pg.ResetOnSpawn = false
pg.IgnoreGuiInset = true
pg.Parent = LP:WaitForChild("PlayerGui")
S.ui = pg

-- Window
local main = Instance.new("Frame", pg)
main.Size = UDim2.new(0, 520, 0, 330)
main.Position = UDim2.new(0.5, -260, 0.35, 0)
main.BackgroundColor3 = Color3.fromRGB(20, 22, 26)
main.BorderSizePixel = 0
Instance.new("UICorner", main).CornerRadius = UDim.new(0, 14)

-- Header
local header = Instance.new("Frame", main)
header.Size = UDim2.new(1, 0, 0, 38)
header.BackgroundColor3 = Color3.fromRGB(28, 30, 36)
header.BorderSizePixel = 0
Instance.new("UICorner", header).CornerRadius = UDim.new(0, 14)

local title = Instance.new("TextLabel", header)
title.Text = "Brookhaven • Pro Menu"
title.Font = Enum.Font.GothamBold
title.TextSize = 16
title.TextColor3 = Color3.fromRGB(230, 230, 235)
title.BackgroundTransparency = 1
title.Size = UDim2.new(0.6, 0, 1, 0)
title.Position = UDim2.new(0, 14, 0, 0)

-- Dragging
do
    local dragging, dragStart, startPos
    addconn(header.InputBegan:Connect(function(input)
        if input.UserInputType==Enum.UserInputType.MouseButton1 then
            dragging = true
            dragStart = input.Position
            startPos = main.Position
            input.Changed:Connect(function()
                if input.UserInputState == Enum.UserInputState.End then dragging = false end
            end)
        end
    end))
    addconn(UIS.InputChanged:Connect(function(input)
        if dragging and input.UserInputType==Enum.UserInputType.MouseMovement then
            local delta = input.Position - dragStart
            main.Position = UDim2.new(startPos.X.Scale, startPos.X.Offset+delta.X, startPos.Y.Scale, startPos.Y.Offset+delta.Y)
        end
    end))
end

-- Tabs
local tabBar = Instance.new("Frame", main)
tabBar.BackgroundTransparency = 1
tabBar.Size = UDim2.new(1, -20, 0, 32)
tabBar.Position = UDim2.new(0, 10, 0, 46)

local function mkTabButton(txt, x)
    local b = Instance.new("TextButton", tabBar)
    b.Text = txt
    b.Font = Enum.Font.Gotham
    b.TextSize = 14
    b.TextColor3 = Color3.fromRGB(230,230,235)
    b.BackgroundColor3 = Color3.fromRGB(40,42,50)
    b.AutoButtonColor = true
    b.BorderSizePixel = 0
    b.Size = UDim2.new(0, 120, 1, 0)
    b.Position = UDim2.new(0, x, 0, 0)
    Instance.new("UICorner", b).CornerRadius = UDim.new(0, 10)
    return b
end

local tabs = {
    Movement = mkTabButton("Movement", 0),
    Teleport = mkTabButton("Teleport", 130),
    Visuals  = mkTabButton("Visuals", 260),
    Misc     = mkTabButton("Misc", 390)
}

-- Content container
local container = Instance.new("Frame", main)
container.BackgroundTransparency = 1
container.Size = UDim2.new(1, -20, 1, -95)
container.Position = UDim2.new(0, 10, 0, 86)

-- Scrolling pages
local function mkPage()
    local sf = Instance.new("ScrollingFrame", container)
    sf.Size = UDim2.new(1, 0, 1, 0)
    sf.BackgroundTransparency = 1
    sf.BorderSizePixel = 0
    sf.Visible = false
    sf.CanvasSize = UDim2.new(0,0,0,0)
    sf.ScrollBarThickness = 6
    sf.ScrollBarImageColor3 = Color3.fromRGB(120,120,130)
    sf.ScrollingDirection = Enum.ScrollingDirection.Y

    local layout = Instance.new("UIListLayout", sf)
    layout.Padding = UDim.new(0, 12)
    layout.SortOrder = Enum.SortOrder.LayoutOrder

    layout:GetPropertyChangedSignal("AbsoluteContentSize"):Connect(function()
        sf.CanvasSize = UDim2.new(0,0,0,layout.AbsoluteContentSize.Y + 12)
    end)
    return sf
end

local pages = { Movement = mkPage(), Teleport = mkPage(), Visuals = mkPage(), Misc = mkPage() }
local current = "Movement"; pages[current].Visible = true

local function switch(tabName)
    for n,pg in pairs(pages) do pg.Visible = (n==tabName) end
    current = tabName
end
for name,btn in pairs(tabs) do addconn(btn.MouseButton1Click:Connect(function() switch(name) end)) end

--== UI ELEMENT HELPERS ==--
local function mkSection(parent, label, h)
    local f = Instance.new("Frame", parent)
    f.Size = UDim2.new(1, -10, 0, h or 84)
    f.BackgroundColor3 = Color3.fromRGB(28, 30, 36)
    f.BorderSizePixel = 0
    Instance.new("UICorner", f).CornerRadius = UDim.new(0, 12)
    local t = Instance.new("TextLabel", f)
    t.Text = label
    t.Font = Enum.Font.GothamBold
    t.TextSize = 14
    t.TextColor3 = Color3.fromRGB(210,210,220)
    t.BackgroundTransparency = 1
    t.Position = UDim2.new(0,12,0,8)
    t.Size = UDim2.new(1,-24,0,18)
    return f
end

local function mkButton(parent, label, cb)
    local b = Instance.new("TextButton", parent)
    b.Text = label
    b.Font = Enum.Font.GothamBold
    b.TextSize = 14
    b.TextColor3 = Color3.fromRGB(230,230,235)
    b.BackgroundColor3 = Color3.fromRGB(45,46,55)
    b.BorderSizePixel = 0
    b.Size = UDim2.new(1, -10, 0, 36)
    Instance.new("UICorner", b).CornerRadius = UDim.new(0, 10)
    addconn(b.MouseButton1Click:Connect(cb))
end

local function mkToggle(parent, label, default, cb)
    local holder = mkSection(parent, label)
    local text = Instance.new("TextLabel", holder)
    text.Text = label
    text.Font = Enum.Font.Gotham
    text.TextSize = 14
    text.TextColor3 = Color3.fromRGB(230,230,235)
    text.BackgroundTransparency = 1
    text.Position = UDim2.new(0,12,0,38)
    text.Size = UDim2.new(1,-70,0,20)

    local btn = Instance.new("TextButton", holder)
    btn.Text = default and "ON" or "OFF"
    btn.Font = Enum.Font.GothamBold
    btn.TextSize = 14
    btn.TextColor3 = default and Color3.fromRGB(60,255,120) or Color3.fromRGB(200,200,210)
    btn.BackgroundColor3 = Color3.fromRGB(45,46,55)
    btn.BorderSizePixel = 0
    btn.Size = UDim2.new(0, 58, 0, 24)
    btn.Position = UDim2.new(1, -70, 0, 38)
    Instance.new("UICorner", btn).CornerRadius = UDim.new(0, 8)

    local state = default
    addconn(btn.MouseButton1Click:Connect(function()
        state = not state
        btn.Text = state and "ON" or "OFF"
        btn.TextColor3 = state and Color3.fromRGB(60,255,120) or Color3.fromRGB(200,200,210)
        cb(state)
    end))
    cb(default)
end

local function mkSlider(parent, label, min, max, default, cb)
    local sec = mkSection(parent, label.." ("..default..")")
    local bar = Instance.new("Frame", sec)
    bar.Size = UDim2.new(1, -24, 0, 6)
    bar.Position = UDim2.new(0, 12, 0, 48)
    bar.BackgroundColor3 = Color3.fromRGB(50,52,60)
    bar.BorderSizePixel = 0
    Instance.new("UICorner", bar).CornerRadius = UDim.new(0, 4)

    local knob = Instance.new("Frame", bar)
    knob.Size = UDim2.new(0, 12, 0, 18)
    knob.Position = UDim2.new((default-min)/(max-min), -6, 0.5, -9)
    knob.BackgroundColor3 = Color3.fromRGB(230,230,235)
    knob.BorderSizePixel = 0
    Instance.new("UICorner", knob).CornerRadius = UDim.new(0, 6)

    local value = default
    local dragging = false
    local labelObj = sec:FindFirstChildOfClass("TextLabel")

    local function updateFromX(x)
        local rel = math.clamp((x - bar.AbsolutePosition.X) / bar.AbsoluteSize.X, 0, 1)
        value = math.floor(min + rel * (max - min))
        knob.Position = UDim2.new(rel, -6, 0.5, -9)
        labelObj.Text = string.format("%s (%d)", label, value)
        cb(value)
    end

    addconn(bar.InputBegan:Connect(function(input)
        if input.UserInputType == Enum.UserInputType.MouseButton1 then
            dragging = true
            updateFromX(input.Position.X)
        end
    end))
    addconn(UIS.InputChanged:Connect(function(input)
        if dragging and input.UserInputType == Enum.UserInputType.MouseMovement then
            updateFromX(input.Position.X)
        end
    end))
    addconn(UIS.InputEnded:Connect(function(input)
        if input.UserInputType == Enum.UserInputType.MouseButton1 then dragging = false end
    end))

    cb(default)
end

local function getPlayerByPartial(s)
    s = s:lower()
    for _,p in ipairs(Players:GetPlayers()) do
        if p ~= LP and p.Name:lower():find(s,1,true) then return p end
        if p ~= LP and p.DisplayName and p.DisplayName:lower():find(s,1,true) then return p end
    end
end

--== MOVEMENT PAGE ==--
mkSlider(pages.Movement, "WalkSpeed", 8, 200, 32, function(v) S.ws = v end)
mkSlider(pages.Movement, "JumpPower", 30, 200, 80, function(v) S.jp = v end)

mkToggle(pages.Movement, "Fly (F to toggle while on)", false, function(on)
    S.fly = on
    if S.fly then
        local root = hrp()
        if root then
            S.flyBV = Instance.new("BodyVelocity")
            S.flyBV.MaxForce = Vector3.new(1e5,1e5,1e5)
            S.flyBV.Velocity = Vector3.zero
            S.flyBV.Parent = root

            S.flyBG = Instance.new("BodyGyro")
            S.flyBG.MaxTorque = Vector3.new(1e5,1e5,1e5)
            S.flyBG.P = 1e5
            S.flyBG.Parent = root
        end
    else
        if S.flyBV then S.flyBV:Destroy() S.flyBV=nil end
        if S.flyBG then S.flyBG:Destroy() S.flyBG=nil end
    end
end)

-- Optional quick key to toggle when enabled
addconn(UIS.InputBegan:Connect(function(i,gp)
    if gp then return end
    if i.KeyCode == Enum.KeyCode.F and S.fly then
        S.fly = false
        if S.flyBV then S.flyBV:Destroy() S.flyBV=nil end
        if S.flyBG then S.flyBG:Destroy() S.flyBG=nil end
        notify("Fly","Fly toggled OFF",3)
    end
end))

mkToggle(pages.Movement, "Noclip", false, function(on)
    S.noclip = on
end)

--== TELEPORT PAGE ==--
do
    local sec = mkSection(pages.Teleport, "Teleport to Player", 120)
    local box = Instance.new("TextBox", sec)
    box.PlaceholderText = "Type part of player name..."
    box.Text = ""
    box.ClearTextOnFocus = false
    box.Font = Enum.Font.Gotham
    box.TextSize = 14
    box.TextColor3 = Color3.fromRGB(230,230,235)
    box.BackgroundColor3 = Color3.fromRGB(40,42,50)
    box.BorderSizePixel = 0
    box.Size = UDim2.new(1,-24,0,28)
    box.Position = UDim2.new(0,12,0,42)
    Instance.new("UICorner", box).CornerRadius = UDim.new(0,8)

    local goBtn = Instance.new("TextButton", sec)
    goBtn.Text = "Teleport"
    goBtn.Font = Enum.Font.GothamBold
    goBtn.TextSize = 14
    goBtn.TextColor3 = Color3.fromRGB(230,230,235)
    goBtn.BackgroundColor3 = Color3.fromRGB(45,46,55)
    goBtn.BorderSizePixel = 0
    goBtn.Size = UDim2.new(0,120,0,28)
    goBtn.Position = UDim2.new(1,-132,0,42)
    Instance.new("UICorner", goBtn).CornerRadius = UDim.new(0,8)

    addconn(goBtn.MouseButton1Click:Connect(function()
        local t = getPlayerByPartial(box.Text)
        local root = hrp()
        if t and root and t.Character and t.Character:FindFirstChild("HumanoidRootPart") then
            root.CFrame = t.Character.HumanoidRootPart.CFrame + Vector3.new(0,3,0)
        else
            notify("Teleport","Target not found or not loaded",3)
        end
    end))
end

mkToggle(pages.Teleport, "Follow Target (uses textbox above)", false, function(on)
    S.follow = on
end)

-- Teleport: random player
mkButton(pages.Teleport, "Teleport to Random Player", function()
    local plist = Players:GetPlayers()
    if #plist <= 1 then return end
    local root = hrp()
    local choice
    repeat
        choice = plist[math.random(1,#plist)]
    until choice ~= LP
    if root and choice and choice.Character and choice.Character:FindFirstChild("HumanoidRootPart") then
        root.CFrame = choice.Character.HumanoidRootPart.CFrame + Vector3.new(0,3,0)
    end
end)

--== VISUALS PAGE ==--
mkToggle(pages.Visuals, "Player ESP (Highlight)", false, function(on)
    S.esp = on
    if not S.espFolder then
        S.espFolder = Instance.new("Folder", pg)
        S.espFolder.Name = "ESP_Objects"
    end
    for _,v in ipairs(S.espFolder:GetChildren()) do v:Destroy() end
    if on then
        for _,p in ipairs(Players:GetPlayers()) do
            if p ~= LP and p.Character then
                local hl = Instance.new("Highlight")
                hl.FillTransparency = 0.75
                hl.OutlineColor = Color3.fromRGB(255,255,255)
                hl.Adornee = p.Character
                hl.Parent = S.espFolder
            end
        end
    end
end)

mkToggle(pages.Visuals, "Night Vision", false, function(on)
    S.nightVision = on
    if on then
        S.cc = S.cc or Instance.new("ColorCorrectionEffect", Lighting)
        S.bloom = S.bloom or Instance.new("BloomEffect", Lighting)
        S.exp = S.exp or Instance.new("ExposureCompensationEffect", Lighting)
        S.cc.Brightness = 0.08; S.cc.Contrast = 0.05; S.cc.Saturation = 0.05
        S.bloom.Intensity = 0.3; S.bloom.Size = 24
        S.exp.ExposureCompensation = 0.6
    else
        if S.cc then S.cc:Destroy(); S.cc=nil end
        if S.bloom then S.bloom:Destroy(); S.bloom=nil end
        if S.exp then S.exp:Destroy(); S.exp=nil end
    end
end)

--== MISC PAGE ==--
mkToggle(pages.Misc, "Anti-AFK", true, function(on)
    S.antiAfk = on
end)

mkButton(pages.Misc, "Rejoin", function()
    TS:Teleport(game.PlaceId, LP)
end)

mkButton(pages.Misc, "Copy Discord (for testers)", function()
    if setclipboard then setclipboard("krissbliss777") end
    notify("Copied","Discord: krissbliss777",3)
end)

--== CORE LOOPS ==--
-- Movement stats enforcement
addconn(RS.Heartbeat:Connect(function()
    local h = hum()
    if h then pcall(function()
        h.WalkSpeed = S.ws
        h.JumpPower = S.jp
        h.UseJumpPower = true
    end) end
end))

-- Noclip
addconn(RS.Stepped:Connect(function()
    if not S.noclip then return end
    local c = char()
    for _,p in ipairs(c:GetDescendants()) do
        if p:IsA("BasePart") then p.CanCollide = false end
    end
end))

-- Fly control (WASD + space/shift)
addconn(RS.Heartbeat:Connect(function()
    if not S.fly or not S.flyBV or not S.flyBG then return end
    local r = hrp(); local h = hum()
    if not r or not h then return end
    local cam = workspace.CurrentCamera
    local dir = Vector3.zero
    if UIS:IsKeyDown(Enum.KeyCode.W) then dir += cam.CFrame.LookVector end
    if UIS:IsKeyDown(Enum.KeyCode.S) then dir -= cam.CFrame.LookVector end
    if UIS:IsKeyDown(Enum.KeyCode.A) then dir -= cam.CFrame.RightVector end
    if UIS:IsKeyDown(Enum.KeyCode.D) then dir += cam.CFrame.RightVector end
    if UIS:IsKeyDown(Enum.KeyCode.Space) then dir += Vector3.new(0,1,0) end
    if UIS:IsKeyDown(Enum.KeyCode.LeftShift) then dir -= Vector3.new(0,1,0) end
    if dir.Magnitude > 0 then dir = dir.Unit * S.flySpeed end
    S.flyBV.Velocity = Vector3.new(dir.X, dir.Y, dir.Z)
    S.flyBG.CFrame = CFrame.new(Vector3.new(), cam.CFrame.LookVector)
end))

-- Follow target logic
addconn(RS.Heartbeat:Connect(function()
    if not S.follow or not S.followTarget then return end
    local r = hrp()
    local t = S.followTarget
    if r and t.Character and t.Character:FindFirstChild("HumanoidRootPart") then
        local tp = t.Character.HumanoidRootPart.Position
        local rp = r.Position
        local offset = (tp - rp)
        if offset.Magnitude > 5 then
            r.CFrame = CFrame.new(tp + Vector3.new(0,3,0))
        end
    end
end))

-- ESP updater
addconn(Players.PlayerAdded:Connect(function(p)
    if not S.esp then return end
    p.CharacterAdded:Connect(function()
        if not S.espFolder then return end
        local hl = Instance.new("Highlight")
        hl.FillTransparency = 0.75
        hl.OutlineColor = Color3.fromRGB(255,255,255)
        hl.Adornee = p.Character
        hl.Parent = S.espFolder
    end)
end))
addconn(Players.PlayerRemoving:Connect(function(p)
    if not S.espFolder then return end
    for _,h in ipairs(S.espFolder:GetChildren()) do
        if h.Adornee and h.Adornee:IsDescendantOf(p.Character or Instance.new("Folder")) then
            h:Destroy()
        end
    end
end))

-- Anti-AFK
addconn(LP.Idled:Connect(function()
    if not S.antiAfk then return end
    VU:Button2Down(Vector2.new(0,0), workspace.CurrentCamera.CFrame); task.wait(0.1); VU:Button2Up(Vector2.new(0,0), workspace.CurrentCamera.CFrame)
end))

-- Track follow target from Teleport textbox
-- (Bind to the last created Teleport textbox if user typed a name and toggled Follow)
do
    local lastBox -- capture the Teleport textbox reference
    for _,child in ipairs(pages.Teleport:GetChildren()) do
        if child:IsA("Frame") then
            for _,c2 in ipairs(child:GetChildren()) do
                if c2:IsA("TextBox") then lastBox = c2 end
            end
        end
    end
    if lastBox then
        addconn(lastBox:GetPropertyChangedSignal("Text"):Connect(function()
            local t = getPlayerByPartial(lastBox.Text)
            if t then S.followTarget = t end
        end))
    end
end

-- Cleanup handle
local function cleanup()
    for _,c in ipairs(S.conns) do pcall(function() c:Disconnect() end) end
    if S.flyBV then S.flyBV:Destroy() end
    if S.flyBG then S.flyBG:Destroy() end
    if S.espFolder then S.espFolder:Destroy() end
    if S.cc then S.cc:Destroy() end
    if S.bloom then S.bloom:Destroy() end
    if S.exp then S.exp:Destroy() end
    if S.ui then S.ui:Destroy() end
end
if getgenv then getgenv().BH_Pro = { cleanup = cleanup } end

notify("Brookhaven Pro", "Loaded. Use responsibly.", 6)