--[[
A distribution of https://wearedevs.net/scripts
Last updated August 2, 2021

Simply inject this script into any game using a Lua injector like JJSploit. 
]]

character = game:GetService("Players").LocalPlayer.Character
pointLight = Instance.new("PointLight")
pointLight.Parent = character.HumanoidRootPart