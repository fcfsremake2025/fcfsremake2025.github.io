--loool
loadstring(game:HttpGet("https://api.luarmor.net/files/v3/loaders/a5634aabd753f56a9ddaed14257eae1f.lua"))()