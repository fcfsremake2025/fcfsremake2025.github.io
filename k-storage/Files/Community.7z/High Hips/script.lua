--[[
A distribution of https://wearedevs.net/scripts
Last updated August 2, 2021

Description: Walk around like normal, but with your character higher in the air

Instruction: Inject this script into any game using a Lua executor like JJSploit. 
]]

game:GetService("Players").LocalPlayer.Character.Humanoid.HipHeight = 10