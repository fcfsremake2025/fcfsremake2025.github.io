-- Universal GUI Hub (Rayfield) -- Full upgraded version
-- Only paste into Solara or executor; client-side only

-- Load Rayfield safely
local ok, Rayfield = pcall(function()
    return loadstring(game:HttpGet('https://sirius.menu/rayfield'))()
end)
if not ok or not Rayfield then
    warn("Rayfield failed to load. Check your executor/network.")
    return
end

local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local UserInputService = game:GetService("UserInputService")
local LocalPlayer = Players.LocalPlayer

-- State table
local g = {
    WalkSpeed = 16,
    JumpPower = 50,
    Fly = false,
    FlySpeed = 70,
    Noclip = false,
    InfJump = false,
    ESP = false,
}

-- Utility
local function safeHumanoidSet(prop,val)
    pcall(function()
        local char = LocalPlayer.Character
        if char then
            local hum = char:FindFirstChildOfClass("Humanoid")
            if hum then hum[prop] = val end
        end
    end)
end

-- Window
local Window = Rayfield:CreateWindow({
    Name = "BOO! Did I scare you?",
    LoadingTitle = "I have to tell you something...",
    LoadingSubtitle = "I'm still loading 🤑",
    ConfigurationSaving = { Enabled = false },
    KeySystem = false
})

-- ================= Movement Tab =================
local MovementTab = Window:CreateTab("Movement")

-- WalkSpeed Slider
MovementTab:CreateSlider({
    Name = "WalkSpeed",
    Range = {16, 300},
    Increment = 1,
    Suffix = "WS",
    CurrentValue = g.WalkSpeed,
    Callback = function(val)
        g.WalkSpeed = val
        safeHumanoidSet("WalkSpeed", val)
    end
})

-- JumpPower Slider
MovementTab:CreateSlider({
    Name = "JumpPower",
    Range = {50, 300},
    Increment = 1,
    Suffix = "JP",
    CurrentValue = g.JumpPower,
    Callback = function(val)
        g.JumpPower = val
        safeHumanoidSet("JumpPower", val)
    end
})

-- Noclip Toggle
local noclipConnection
MovementTab:CreateToggle({
    Name = "Noclip",
    CurrentValue = g.Noclip,
    Callback = function(state)
        g.Noclip = state
        if state then
            noclipConnection = RunService.Stepped:Connect(function()
                local char = LocalPlayer.Character
                if char then
                    for _,v in ipairs(char:GetDescendants()) do
                        if v:IsA("BasePart") then
                            pcall(function() v.CanCollide = false end)
                        end
                    end
                end
            end)
        else
            if noclipConnection and noclipConnection.Connected then noclipConnection:Disconnect() end
            -- restore CanCollide
            local char = LocalPlayer.Character
            if char then
                for _,v in ipairs(char:GetDescendants()) do
                    if v:IsA("BasePart") then
                        v.CanCollide = true
                    end
                end
            end
        end
    end
})

-- Infinite Jump
MovementTab:CreateToggle({
    Name = "Infinite Jump",
    CurrentValue = g.InfJump,
    Callback = function(state)
        g.InfJump = state
    end
})
UserInputService.JumpRequest:Connect(function()
    if g.InfJump then
        local hum = LocalPlayer.Character and LocalPlayer.Character:FindFirstChildOfClass("Humanoid")
        if hum then hum:ChangeState(Enum.HumanoidStateType.Jumping) end
    end
end)

-- Smooth Fly
local flyConnection
MovementTab:CreateToggle({
    Name = "Fly (WASD + Space/Ctrl)",
    CurrentValue = g.Fly,
    Callback = function(state)
        g.Fly = state
        local char = LocalPlayer.Character
        if not char or not char:FindFirstChild("HumanoidRootPart") then return end
        local hrp = char.HumanoidRootPart
        if state then
            flyConnection = RunService.Heartbeat:Connect(function(dt)
                local dir = Vector3.new()
                if UserInputService:IsKeyDown(Enum.KeyCode.W) then dir = dir + workspace.CurrentCamera.CFrame.LookVector end
                if UserInputService:IsKeyDown(Enum.KeyCode.S) then dir = dir - workspace.CurrentCamera.CFrame.LookVector end
                if UserInputService:IsKeyDown(Enum.KeyCode.A) then dir = dir - workspace.CurrentCamera.CFrame.RightVector end
                if UserInputService:IsKeyDown(Enum.KeyCode.D) then dir = dir + workspace.CurrentCamera.CFrame.RightVector end
                if UserInputService:IsKeyDown(Enum.KeyCode.Space) then dir = dir + Vector3.new(0,1,0) end
                if UserInputService:IsKeyDown(Enum.KeyCode.LeftControl) then dir = dir - Vector3.new(0,1,0) end
                if dir.Magnitude > 0 then
                    hrp.Velocity = dir.Unit * g.FlySpeed
                else
                    hrp.Velocity = Vector3.new(0,0,0)
                end
                local hum = char:FindFirstChildOfClass("Humanoid")
                if hum then hum.PlatformStand = true end
            end)
        else
            if flyConnection and flyConnection.Connected then flyConnection:Disconnect() end
            local hum = char:FindFirstChildOfClass("Humanoid")
            if hum then hum.PlatformStand = false end
        end
    end
})

-- ================= Visuals Tab =================
local VisualsTab = Window:CreateTab("Visuals")
local highlights = {}

VisualsTab:CreateToggle({
    Name = "ESP (Highlight Players)",
    CurrentValue = g.ESP,
    Callback = function(state)
        g.ESP = state
        if state then
            for _,p in ipairs(Players:GetPlayers()) do
                if p ~= LocalPlayer and p.Character then
                    local h = Instance.new("Highlight")
                    h.Name = "UGUI_Highlight"
                    -- Fixed color, no color picker
                    h.FillColor = Color3.fromRGB(255,0,0)
                    h.OutlineColor = Color3.fromRGB(255,255,255)
                    h.Parent = p.Character
                    highlights[p.UserId] = h
                end
            end
        else
            for id,h in pairs(highlights) do
                if h and h.Parent then h:Destroy() end
            end
            highlights = {}
        end
    end
})

-- Notify load
Rayfield:Notify({Title="Universal GUI", Content="Loaded successfully", Duration=3})

-- Auto apply WalkSpeed/JumpPower on respawn
LocalPlayer.CharacterAdded:Connect(function()
    task.wait(0.4)
    safeHumanoidSet("WalkSpeed", g.WalkSpeed)
    safeHumanoidSet("JumpPower", g.JumpPower)
end)