getgenv().simple_settings = {
    ["MASTERY"] = {
        ["ACTIVE"] = true,
        ["METHOD"] = "Full",
    },

    ["OBJECTIVE"] = {
        ["GODHUMAN"] = true,

        ["RACE-CONFIGURE"] = {
            ["RACE"] = {"Mink"}, -- ✅ Only allow Mink
            ["RACE-LOCK"] = true, -- ✅ Reroll until Mink
            ["RACE-V3"] = true, -- ✅ Upgrade to V3
        },

        ["FRAGMENT"] = 3000000,

        -- SWORD
        ["CANVANDER"] = true,
	["Rengoku"] = true,
	["Saber"] = true,
        ["BUDDY-SWORD"] = true,
        ["CURSED-DUAL-KATANA"] = true,
        ["SHARK-ANCHOR"] = true,

        -- GUN
        ["ACIDUM-RIFLE"] = true,
        ["Kabucha"] = true,
        ["VENOM-BOW"] = true,
        ["SOUL-GUITAR"] = true,

        -- AURA
        ["COLOR-HAKI"] = {"Pure Red", "Winter Sky", "Snow White"},
    },

    ["FRUITPURCHASE"] = false,
    ["PRIORITYFRUIT"] = {
        [1] = "Dragon-Dragon",
        [2] = "Dough-Dough",
        [3] = "Flame-Flame",
        [4] = "Rumble-Rumble",
        [5] = "Human-Human: Buddha",
        [6] = "Dark-Dark",
    },

    ["FPSCAP"] = 30,
    ["LOWTEXTURE"] = true
}

loadstring(game:HttpGet("https://raw.githubusercontent.com/simple-hubs/contents/refs/heads/main/bloxfruit-kaitan-main.lua"))()
