local Players = game:GetService("Players")
local UserInputService = game:GetService("UserInputService")
local playerActions = {}
local playerList = {}
local isNoclipEnabled = false
local isFlying = false

local function toggleNoclip()
    isNoclipEnabled = not isNoclipEnabled
    local character = Players.LocalPlayer.Character
    if character then
        for _, part in pairs(character:GetDescendants()) do
            if part:IsA("BasePart") then
                part.CanCollide = not isNoclipEnabled
            end
        end
    end
end

local function toggleFly()
    isFlying = not isFlying
    local character = Players.LocalPlayer.Character
    if character then
        local humanoid = character:FindFirstChildOfClass("Humanoid")
        if humanoid then
            humanoid.PlatformStand = isFlying
        end
    end
end

local function performActionOnPlayer(player, action)
    local targetCharacter = player.Character
    if targetCharacter then
        if action == "Kill" then
            targetCharacter:BreakJoints()
        elseif action == "Fling" then
            local bodyVelocity = Instance.new("BodyVelocity")
            bodyVelocity.Velocity = Vector3.new(0, 100, 0)
            bodyVelocity.MaxForce = Vector3.new(4000, 4000, 4000)
            bodyVelocity.Parent = targetCharacter.PrimaryPart
            game.Debris:AddItem(bodyVelocity, 0.5)
        elseif action == "Squish" then
            targetCharacter:FindFirstChildOfClass("Humanoid").Health = 0
        end
    end
end

local function showPlayerOptions()
    playerList = Players:GetPlayers()
    for i, player in ipairs(playerList) do
        print(i .. ": " .. player.Name)
    end
    print("Select a player by number:")
    local selectedPlayerIndex = tonumber(io.read())
    local selectedPlayer = playerList[selectedPlayerIndex]
    
    if selectedPlayer then
        print("Choose an action: Kill, Fling, Squish")
        local action = io.read()
        performActionOnPlayer(selectedPlayer, action)
    end
end

UserInputService.InputBegan:Connect(function(input, gameProcessed)
    if not gameProcessed then
        if input.KeyCode == Enum.KeyCode.O then
            showPlayerOptions()
        elseif input.KeyCode == Enum.KeyCode.N then
            toggleNoclip()
        elseif input.KeyCode == Enum.KeyCode.F then
            toggleFly()
        end
    end
end)